﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using MMO.Xrm.AzureFunctions.Utility.Framework.Interfaces;
using MMO.Xrm.GroupSales.AzureFunctions.Payload;
using MMO.Xrm.Model;

namespace MMO.Xrm.GroupSales.AzureFunctions.BusinessLogic
{
    internal class QrsCompleteBusinessLogic : BusinessLogicBase
    {
        private QrsPayload _data { get; }

        internal QrsCompleteBusinessLogic(IOrganizationServiceAsync2Pool serviceClientPool, ILogger logger, DateTime TriggerTimeStamp, QrsPayload data)
            : base(serviceClientPool, logger, TriggerTimeStamp)
        {
            _data = data;
        }

        internal async override Task<Task> AbstractBusinessLogic()
        {
            var opportunities = CrmHelper.GetOpportunitiesByMmoQrsQuoteId(ServiceClient, _data!.qrsQuoteId);
            if (opportunities.Entities?.Count > 1)
            {
                throw new Exception($"Multiple Opportunities found for QRS Quote ID: {_data.qrsQuoteId}");
            }
            var opportunity = opportunities.Entities?.FirstOrDefault();

            var opportunityHasQuote = opportunity != null && opportunity.Contains(Opportunity.Fields.MMo_QRS_QuoteId_Text);
            if (!opportunityHasQuote)
            {
                Logger.LogWarning($"Opportunity not found for QRS Quote ID: {_data.qrsQuoteId}");
                return Task.CompletedTask;
            }

            if (opportunity != null)
            {
                // Prevent out of sequence processing
                opportunity.TryGetAttributeValue(Opportunity.Fields.MMo_Integration_Modified_On, out DateTime integrationModifiedOn);
                if (integrationModifiedOn > TriggerTimeStamp)
                {
                    throw new Exception($"Stale Data due to TriggerTimestamp.");
                }

                await UpsertOpportunity(opportunity.Id, _data, QrsMessageType.Complete, TriggerTimeStamp);
            }

            return Task.CompletedTask;
        }
    }
}
