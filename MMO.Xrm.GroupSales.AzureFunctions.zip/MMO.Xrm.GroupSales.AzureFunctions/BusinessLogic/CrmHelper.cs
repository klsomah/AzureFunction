﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using MMO.Xrm.Model;
using Microsoft.PowerPlatform.Dataverse.Client;
using MMO.Xrm.AzureFunctions.Utility.Framework.Interfaces;

namespace MMO.Xrm.GroupSales.AzureFunctions.BusinessLogic
{
    public static class CrmHelper
    {
		public static EntityCollection GetLeadsMmoQrsQuoteId(IPoolingOrganizationServiceAsync2 serviceClient, string quoteId)
		{

			string fetchXml = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                   <entity name='{Lead.EntityLogicalName}'>
                                     <attribute name='{Lead.Fields.LeadId}' />
                                     <attribute name='{Lead.Fields.MMo_QRS_QuoteId_Text}' />
                                     <attribute name='{Lead.Fields.MMo_Integration_Modified_On}' />
                                     <filter>
                                       <condition attribute='{Lead.Fields.MMo_QRS_QuoteId_Text}' operator='eq' value='{quoteId}' />
                                     </filter>
                                     <order attribute='modifiedon' descending='true' />
                                   </entity>
                                 </fetch>";

			FetchExpression leadQuery = new FetchExpression(fetchXml);

			return serviceClient.RetrieveMultiple(leadQuery);
		}

		public static EntityCollection GetOpportunitiesByMmoQrsQuoteId(IPoolingOrganizationServiceAsync2 serviceClient, string quoteId)
        {

            string fetchXml = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='{Opportunity.EntityLogicalName}'>
                                    <attribute name='{Opportunity.Fields.OpportunityId}' />
                                    <attribute name='{Opportunity.Fields.MMo_QRS_QuoteId_Text}' />
                                    <attribute name='{Opportunity.Fields.MMo_Integration_Modified_On}' />
                                    <filter type='and'>
                                      <condition attribute='{Opportunity.Fields.MMo_QRS_QuoteId_Text}' operator='eq' value='{quoteId}' />
                                    </filter>
                                    <order attribute='modifiedon' descending='true' />
                                  </entity>
                                </fetch>";

            FetchExpression opportunityQuery = new FetchExpression(fetchXml);

            EntityCollection opportunityCollection = serviceClient.RetrieveMultiple(opportunityQuery);
            return opportunityCollection;

        }

        public static EntityCollection GetAccountTaxId(IPoolingOrganizationServiceAsync2 serviceClient, string taxId, int typeCode)
        {

            string fetchXml = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='{Account.EntityLogicalName}'>
                                    <attribute name='{Account.Fields.AccountId}'/>
                                    <attribute name='{Account.Fields.AccountNumber}'/>
                                    <attribute name='{Account.Fields.HsL_ClientNumber}'/>
                                    <attribute name='{Account.Fields.HsL_GroupTypeCode}'/>
                                    <attribute name='{Account.Fields.HsL_AgencyNumber}'/>
                                    <attribute name='{Account.Fields.HsL_AgencyCode}'/>
                                    <attribute name='{Account.Fields.HsL_FederalTaxId}'/>
                                    <attribute name='{Account.Fields.CustomerTypeCode}'/>
                                    <attribute name='{Account.Fields.MMo_Integration_Modified_On}'/>
                                    <filter type='and'>
                                      <condition attribute='{Account.Fields.CustomerTypeCode}' operator='eq' value='{typeCode}'/>
                                      <condition attribute='{Account.Fields.HsL_FederalTaxId}' operator='eq' value='{taxId}'/>
                                    </filter>
                                    <order attribute='modifiedon' descending='true' />
                                  </entity>
                                </fetch> ";

            FetchExpression accountQuery = new FetchExpression(fetchXml);

            EntityCollection accountCollection = serviceClient.RetrieveMultiple(accountQuery);
            return accountCollection;
        }

		public static EntityCollection GetAccountByEin(IPoolingOrganizationServiceAsync2 serviceClient, string ein)
		{

			string fetchXml = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='{Account.EntityLogicalName}'>
                                    <attribute name='{Account.Fields.AccountId}'/>
                                    <attribute name='{Account.Fields.AccountNumber}'/>
                                    <attribute name='{Account.Fields.HsL_ClientNumber}'/>
                                    <attribute name='{Account.Fields.HsL_GroupTypeCode}'/>
                                    <attribute name='{Account.Fields.HsL_AgencyNumber}'/>
                                    <attribute name='{Account.Fields.HsL_AgencyCode}'/>
                                    <attribute name='{Account.Fields.HsL_FederalTaxId}'/>
                                    <attribute name='{Account.Fields.CustomerTypeCode}'/>
                                    <attribute name='{Account.Fields.MMo_Integration_Modified_On}'/>
                                    <filter type='and'>
                                      <condition attribute='{Account.Fields.HsL_FederalTaxId}' operator='eq' value='{ein}'/>
                                    </filter>
                                    <filter type='or'>
                                      <condition attribute='{Account.Fields.CustomerTypeCode}' operator='eq' value='{(int)Account_CustomerTypeCode.EmployerGroup}' />
                                      <condition attribute='{Account.Fields.CustomerTypeCode}' operator='eq' value='{(int)Account_CustomerTypeCode.ProspectiveGroup}' />
                                    </filter>
                                    <order attribute='modifiedon' descending='true' />
                                  </entity>
                                </fetch> ";

			FetchExpression accountQuery = new FetchExpression(fetchXml);

			EntityCollection accountCollection = serviceClient.RetrieveMultiple(accountQuery);
			return accountCollection;
		}

		public static EntityCollection GetAccountByGroupNumber(IPoolingOrganizationServiceAsync2 serviceClient, string groupNumber)
		{

			string fetchXml = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='{Account.EntityLogicalName}'>
                                    <attribute name='{Account.Fields.AccountId}'/>
                                    <attribute name='{Account.Fields.AccountNumber}'/>
                                    <attribute name='{Account.Fields.HsL_ClientNumber}'/>
                                    <attribute name='{Account.Fields.HsL_GroupTypeCode}'/>
                                    <attribute name='{Account.Fields.HsL_AgencyNumber}'/>
                                    <attribute name='{Account.Fields.HsL_AgencyCode}'/>
                                    <attribute name='{Account.Fields.HsL_FederalTaxId}'/>
                                    <attribute name='{Account.Fields.CustomerTypeCode}'/>
                                    <attribute name='{Account.Fields.MMo_Integration_Modified_On}'/>
                                    <filter type='and'>
                                      <condition attribute='{Account.Fields.CustomerTypeCode}' operator='eq' value='{(int)Account_CustomerTypeCode.EmployerGroup}'/>
                                      <condition attribute='{Account.Fields.HsL_ClientNumber}' operator='eq' value='{groupNumber}'/>
                                    </filter>
                                    <order attribute='modifiedon' descending='true' />
                                  </entity>
                                </fetch> ";

			FetchExpression accountQuery = new FetchExpression(fetchXml);
			
			return serviceClient.RetrieveMultiple(accountQuery);
		}

		public static EntityCollection GetContactByTaxId(IPoolingOrganizationServiceAsync2 serviceClient, string agentId)
        {

            string fetchXml = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                   <entity name='{Contact.EntityLogicalName}'>
                                     <attribute name='{Contact.Fields.ContactId}'/>
                                     <attribute name='{Contact.Fields.MMo_Contact_Type_Code}'/>
                                     <attribute name='{Contact.Fields.MMo_Small_Group_Sales_Consultant_Id}'/>
                                     <attribute name='{Contact.Fields.MMo_Integration_Modified_On}'/>
                                     <filter type='and'>
                                       <condition attribute='{Contact.Fields.CustomerTypeCode}' operator='eq' value='{(int)Contact_CustomerTypeCode.Broker}'/>
                                       <condition attribute='{Contact.Fields.MMo_FederalTaxId_Text}' operator='eq' value='{agentId}'/>
                                     </filter>
                                     <order attribute='modifiedon' descending='true' />
                                    </entity>
                                 </fetch> ";

            FetchExpression contactQuery = new FetchExpression(fetchXml);

            EntityCollection accountCollection = serviceClient.RetrieveMultiple(contactQuery);
            return accountCollection;

        }

        public static async Task<EntityCollection> GetStateByAbbreviation(IPoolingOrganizationServiceAsync2 cachedServiceClient, string abbreviation)
        {

            string fetchXml = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                   <entity name='{HsL_State.EntityLogicalName}'>
                                     <attribute name='{HsL_State.Fields.HsL_StateId}'/>
                                     <attribute name='{HsL_State.Fields.HsL_Abbreviation}'/>
                                     <filter type='and'>
                                       <condition attribute='{HsL_State.Fields.HsL_Abbreviation}' operator='eq' value='{abbreviation}'/>
                                     </filter>
                                     <order attribute='modifiedon' descending='true' />
                                   </entity>
                                 </fetch>";

            FetchExpression stateQuery = new FetchExpression(fetchXml);

            EntityCollection stateCollection = await cachedServiceClient.CachedRetrieveMultipleAsync(stateQuery);
            return stateCollection;

        }

        public static async Task<EntityCollection> GetCountyByCode(IPoolingOrganizationServiceAsync2 cachedServiceClient, string code)
        {

            string fetchXml = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                   <entity name='{MMo_County.EntityLogicalName}'>
                                     <attribute name='{MMo_County.Fields.MMo_CountyId}'/>
                                     <attribute name='{MMo_County.Fields.MMo_Name}'/>
                                     <attribute name='{MMo_County.Fields.MMo_Region}'/>
                                     <filter type='and'>
                                       <condition attribute='{MMo_County.Fields.MMo_County_Code}' operator='eq' value='{code}'/>
                                     </filter>
                                     <order attribute='modifiedon' descending='true' />
                                   </entity>
                                 </fetch>";

            FetchExpression countyQuery = new FetchExpression(fetchXml);

            EntityCollection countyCollection = await cachedServiceClient.CachedRetrieveMultipleAsync(countyQuery);
            return countyCollection;

        }

        public static async Task<EntityCollection> GetCountryByName(IPoolingOrganizationServiceAsync2 cachedServiceClient, string name)
        {

            string fetchXml = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                   <entity name='{MMo_Country.EntityLogicalName}'>
                                     <attribute name='{MMo_Country.Fields.MMo_CountryId}'/>
                                     <attribute name='{MMo_Country.Fields.MMo_Name}'/>
                                     <filter type='and'>
                                       <condition attribute='{MMo_Country.Fields.MMo_Name}' operator='eq' value='{name}'/>
                                     </filter>
                                     <order attribute='modifiedon' descending='true' />
                                   </entity>
                                 </fetch>";

            FetchExpression countryQuery = new FetchExpression(fetchXml);

            EntityCollection countryCollection = await cachedServiceClient.CachedRetrieveMultipleAsync(countryQuery);
            return countryCollection;

        }

        public static Task<EntityCollection> GetOpenOpportunities(IPoolingOrganizationServiceAsync2 serviceClient)
        {

            string fetchXml = $@"<fetch>
                                   <entity name='{Opportunity.EntityLogicalName}'>
                                     <attribute name='{Opportunity.Fields.OpportunityId}' />
                                     <attribute name='{Opportunity.Fields.MMo_QRS_QuoteId_Text}' />
                                     <attribute name='{Opportunity.Fields.MMo_Underwriting_Completed_Date}' />
                                     <attribute name='{Opportunity.Fields.MMo_Last_Tracked_OnBase_Queue}' />
                                     <attribute name='{Opportunity.Fields.MMo_Integration_Modified_On}' />
                                     <filter type='and'>
                                       <condition attribute='{Opportunity.Fields.StateCode}' operator='eq' value='0' />
                                       <condition attribute='{Opportunity.Fields.MMo_QRS_QuoteId_Text}' operator='not-null'/>
                                     </filter>
                                     <order attribute='modifiedon' descending='true' />
                                   </entity>
                                 </fetch>";

            FetchExpression opportunityQuery = new FetchExpression(fetchXml);

            EntityCollection opportunityCollection = serviceClient.RetrieveMultiple(opportunityQuery);
            return Task.FromResult(opportunityCollection);

        }

        public static int QrsQuoteStatus(string status)
        {
            switch (status)
            {
                case "IP":
                    return (int)MMo_Quote_Status_Gc.InProcessProposal;
                case "FP":
                    return (int)MMo_Quote_Status_Gc.FinalizedProposal;
                case "AP":
                    return (int)MMo_Quote_Status_Gc.ApprovedProposal;
                case "DP":
                    return (int)MMo_Quote_Status_Gc.DeletedProposalProposalMarkedForDeletion;
                case "CR":
                    return (int)MMo_Quote_Status_Gc.CompleteRenewal;
                case "ER":
                    return (int)MMo_Quote_Status_Gc.ErrorRenewal;
                case "SR":
                    return (int)MMo_Quote_Status_Gc.RestartRenewal;
                case "XR":
                    return (int)MMo_Quote_Status_Gc.CancelRenewal;
                case "RR":
                    return (int)MMo_Quote_Status_Gc.ReviewRenewal;
                case "AE":
                    return (int)MMo_Quote_Status_Gc.AutoExport;
                case "IQ":
                    return (int)MMo_Quote_Status_Gc.IndividualQuoteWithNoErrors;
                case "IE":
                    return (int)MMo_Quote_Status_Gc.IndividualQuoteWithErrors;
                default:
                    return (int)MMo_Quote_Status_Gc.UnknownStatusSeeQrs;
            }
        }

        public static int CoverageIndicator(string name)
        {
            switch (name.ToLower())
            {
                case "health":
                    return (int)MMo_Coverage_Indicator_Gc.Health;
                case "health & life":
                    return (int)MMo_Coverage_Indicator_Gc.HealthLife;
                case "life":
                    return (int)MMo_Coverage_Indicator_Gc.Life;
                case "ancillary":
                    return (int)MMo_Coverage_Indicator_Gc.Ancillary;
                default:
                    return (int)MMo_Coverage_Indicator_Gc.UnknownCoverageSeeQrs;
            }
        }

        public static int EmployeeCount(int count)
        {
            switch (count)
            {
                case > 0 and <= 50:
                    return (int)MMo_Employee_Count_Gc._150;
                case > 50 and <= 99:
                    return (int)MMo_Employee_Count_Gc._5199;
                default:
                    return (int)MMo_Employee_Count_Gc._100;
            }
        }

        public static int MedicalTier(int tier)
        {
            switch (tier)
            {
                case 1:
                    return (int)MMo_Medical_Tier_Gc._1;
                case 2:
                    return (int)MMo_Medical_Tier_Gc._2;
                case 3:
                    return (int)MMo_Medical_Tier_Gc._3;
                case 4:
                    return (int)MMo_Medical_Tier_Gc._4;
                case 5:
                    return (int)MMo_Medical_Tier_Gc._5;
                case 6:
                    return (int)MMo_Medical_Tier_Gc._6;
                case 7:
                    return (int)MMo_Medical_Tier_Gc._7;
                case 8:
                    return (int)MMo_Medical_Tier_Gc._8;
                case 9:
                    return (int)MMo_Medical_Tier_Gc._9;
                case 10:
                    return (int)MMo_Medical_Tier_Gc._10;
                case 11:
                    return (int)MMo_Medical_Tier_Gc._11;
                case 12:
                    return (int)MMo_Medical_Tier_Gc._12;
                case 13:
                    return (int)MMo_Medical_Tier_Gc._13;
                case 14:
                    return (int)MMo_Medical_Tier_Gc._14;
                case 15:
                    return (int)MMo_Medical_Tier_Gc._15;
                case 16:
                    return (int)MMo_Medical_Tier_Gc._16;
                case 17:
                    return (int)MMo_Medical_Tier_Gc._17;
                case 18:
                    return (int)MMo_Medical_Tier_Gc._18;
                case 19:
                    return (int)MMo_Medical_Tier_Gc._19;
                case 20:
                    return (int)MMo_Medical_Tier_Gc._20;
                case 21:
                    return (int)MMo_Medical_Tier_Gc._21;
                case 22:
                    return (int)MMo_Medical_Tier_Gc._22;
                case 23:
                    return (int)MMo_Medical_Tier_Gc._23;
                case 24:
                    return (int)MMo_Medical_Tier_Gc._24;
                case 25:
                    return (int)MMo_Medical_Tier_Gc._25;
                case 26:
                    return (int)MMo_Medical_Tier_Gc._26;
                case 27:
                    return (int)MMo_Medical_Tier_Gc._27;
                case 28:
                    return (int)MMo_Medical_Tier_Gc._28;
                case 29:
                    return (int)MMo_Medical_Tier_Gc._29;
                case 30:
                    return (int)MMo_Medical_Tier_Gc._30;
                case 31:
                    return (int)MMo_Medical_Tier_Gc._31;
                case 32:
                    return (int)MMo_Medical_Tier_Gc._32;
                case 33:
                    return (int)MMo_Medical_Tier_Gc._33;
                case 34:
                    return (int)MMo_Medical_Tier_Gc._34;
                case 35:
                    return (int)MMo_Medical_Tier_Gc._35;
                case 36:
                    return (int)MMo_Medical_Tier_Gc._36;
                case 37:
                    return (int)MMo_Medical_Tier_Gc._37;
                case 38:
                    return (int)MMo_Medical_Tier_Gc._38;
                case 39:
                    return (int)MMo_Medical_Tier_Gc._39;
                case 40:
                    return (int)MMo_Medical_Tier_Gc._40;
                case 41:
                    return (int)MMo_Medical_Tier_Gc._41;
                default:
                    return 0;

            }
        }
	}
}
