﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Xrm.Sdk;
using MMO.Xrm.AzureFunctions.Utility.Framework.Interfaces;
using MMO.Xrm.GroupSales.AzureFunctions.Payload;
using MMO.Xrm.Model;

namespace MMO.Xrm.GroupSales.AzureFunctions.BusinessLogic
{
    internal class ScheduledJobsBusinessLogic : BusinessLogicBase
    {
        internal ScheduledJobsBusinessLogic(IOrganizationServiceAsync2Pool serviceClientPool, ILogger logger, DateTime TriggerTimeStamp)
            : base(serviceClientPool, logger, TriggerTimeStamp)
        {
        }

        internal async override Task<Task> AbstractBusinessLogic()
        {
            //TODO: When the MBStatus is set to MU-COMPLETE set the CRM status to TBD, otherwise if the QueueNum is TBD then set the CRM status to TBD
            var opportunities = await GetOpenOpportunities();
            var openOpportunitiesQuoteIds = GetOpenOpportunitiesQuoteIds(opportunities);
            var onBaseQuotes = OnBaseHelper.GetOnBaseOpenRecords(openOpportunitiesQuoteIds);

            foreach (var quote in onBaseQuotes)
            {
                var opportunityRecord = opportunities?.FirstOrDefault(v => v.QuoteId?.Trim() == quote.QrsId?.Trim());
                if (opportunityRecord == null || string.IsNullOrWhiteSpace(opportunityRecord.OpportunityId))
                {
                    continue;
                }

                var opportunityId = new Guid(opportunityRecord.OpportunityId);
                var queueNum = opportunityRecord.LastTracked;
                var addQueueAutoPost = false;
                var addCompletedAutoPost = false;
                var currentQueueName = queueNum != null ? OnBaseHelper.GetQueueName(queueNum.ToString()) : string.Empty;
                var updateStatus = quote.MbStatus?.Trim() == "MU-COMPLETE";
                DateTime? completedDate = opportunityRecord.CompletedDate;

                if (updateStatus)
                {

                    if (completedDate == null)
                    {
                        completedDate = DateTime.UtcNow;
                        addCompletedAutoPost = true;
                    }
                }

                if (int.TryParse(quote.QueueNum, out var newQueueNum) && newQueueNum != queueNum)
                {
                    addQueueAutoPost = true;
                }


                UpdateOpportunityStatus(opportunityId, Convert.ToInt32(quote.QueueNum), updateStatus, completedDate, queueNum);


                if (addQueueAutoPost && !string.IsNullOrWhiteSpace(quote.QueueName))
                {
                    var postMessage = $"OnBase queue changed from {currentQueueName} to {quote.QueueName}";
                    CreateAutoPost(opportunityId, postMessage);
                }

                if (addCompletedAutoPost)
                {
                    const string postMessage = $"OnBase Pre-screen record has been marked Complete";
                    CreateAutoPost(opportunityId, postMessage);
                }
            }

            return Task.CompletedTask;
        }

        /// <summary>
        /// Update Opportunity Status
        /// </summary>
        /// <param name="opportunityId"></param>
        /// <param name="lastUpdatedQueue"></param>
        /// <param name="updateStateCode"></param>
        /// <param name="completedDate"></param>
        /// <param name="currentQueue"></param>
        /// <returns></returns>
        public void UpdateOpportunityStatus(Guid opportunityId, int lastUpdatedQueue, bool updateStateCode, DateTime? completedDate, int? currentQueue)
        {
            var opportunity = new Entity(Opportunity.EntityLogicalName, opportunityId)
            {
                [Opportunity.Fields.MMo_Last_Tracked_OnBase_Queue] = lastUpdatedQueue
            };

            if (completedDate != null && updateStateCode)
            {
                opportunity[Opportunity.Fields.MMo_Underwriting_Completed_Date] = completedDate;
            }

            if (updateStateCode)
            {
                opportunity[Opportunity.Fields.MMo_OnBase_Status_Code] = new OptionSetValue((int)MMo_OnBase_Status_Gc.Complete);
            }
            else
            {
                opportunity[Opportunity.Fields.MMo_OnBase_Status_Code] = new OptionSetValue((int)MMo_OnBase_Status_Gc.InProcess);
            }
            bool isQueueChanged = lastUpdatedQueue != currentQueue;
            bool isUnderwritingDatePresent = opportunity.GetAttributeValue<DateTime?>(Opportunity.Fields.MMo_SentToUnderwriting_Date) != null;

            if (isQueueChanged && !isUnderwritingDatePresent)
            {
                opportunity[Opportunity.Fields.MMo_SentToUnderwriting_Date] = DateTime.Now;
            }

            ServiceClient.Update(opportunity);
        }

        private async Task<List<OpportunityData>?> GetOpenOpportunities()
        {
            var openOpportunities = new List<OpportunityData>();
            var opportunities = await CrmHelper.GetOpenOpportunities(ServiceClient);

            if (opportunities.Entities.Count == 0)
            {
                return openOpportunities;
            }

            foreach (var entity in opportunities.Entities)
            {
                var opportunityData = new OpportunityData();

                if (entity.Contains(Opportunity.Fields.OpportunityId) && entity[Opportunity.Fields.OpportunityId] != null)
                {
                    opportunityData.OpportunityId = entity[Opportunity.Fields.OpportunityId].ToString();
                }

                if (entity.Contains(Opportunity.Fields.MMo_QRS_QuoteId_Text) && entity[Opportunity.Fields.MMo_QRS_QuoteId_Text] != null)
                {
                    opportunityData.QuoteId = entity[Opportunity.Fields.MMo_QRS_QuoteId_Text].ToString();
                }

                if (entity.Contains(Opportunity.Fields.MMo_Last_Tracked_OnBase_Queue) && entity[Opportunity.Fields.MMo_Last_Tracked_OnBase_Queue] != null)
                {
                    if (int.TryParse(entity[Opportunity.Fields.MMo_Last_Tracked_OnBase_Queue].ToString(), out int lastTracked))
                    {
                        opportunityData.LastTracked = lastTracked;
                    }
                }

                if (entity.Contains(Opportunity.Fields.MMo_Underwriting_Completed_Date) && entity[Opportunity.Fields.MMo_Underwriting_Completed_Date] != null)
                {
                    if (DateTime.TryParse(entity[Opportunity.Fields.MMo_Underwriting_Completed_Date].ToString(), out DateTime completedDate))
                    {
                        opportunityData.CompletedDate = completedDate;
                    }
                }

                openOpportunities.Add(opportunityData);
            }

            return openOpportunities;
        }



        private string GetOpenOpportunitiesQuoteIds(List<OpportunityData>? opportunities)
        {
            var quotes = "";
            if (opportunities is { Count: 0 })
            {
                return quotes;
            }

            quotes = opportunities!.Aggregate(quotes, (current, opportunity) => $"{current} '{opportunity.QuoteId}',");

            if (quotes.Length <= 0)
            {
                return quotes;
            }
            quotes = quotes.Substring(0, quotes.Length - 1);

            return quotes;
        }


        private void CreateAutoPost(Guid opportunityId, string postMessage)
        {
            var post = new Entity(Post.EntityLogicalName)
            {
                [Post.Fields.Text] = postMessage,
                [Post.Fields.Source] = new OptionSetValue((int)Post_Source.AutoPost),
                [Post.Fields.RegardingObjectId] = new EntityReference(Opportunity.EntityLogicalName, opportunityId)
            };

            ServiceClient.Create(post);
        }

    }
}
