﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Extensions.Logging;
using Microsoft.Xrm.Sdk;
using MMO.Xrm.AzureFunctions.Utility.Framework.Interfaces;
using MMO.Xrm.GroupSales.AzureFunctions.Payload;
using MMO.Xrm.Model;

namespace MMO.Xrm.GroupSales.AzureFunctions.BusinessLogic
{
    internal class QrsSubmitBusinessLogic : BusinessLogicBase
    {
        private QrsPayload _data { get; }

        internal QrsSubmitBusinessLogic(IOrganizationServiceAsync2Pool serviceClientPool, ILogger logger, DateTime TriggerTimeStamp, QrsPayload data)
            : base(serviceClientPool, logger, TriggerTimeStamp)
        {
            _data = data;
        }

        internal async override Task<Task> AbstractBusinessLogic()
        {
            // Ensure the Quote doesn't already exist for the QRS Quote ID
            var leads = CrmHelper.GetLeadsMmoQrsQuoteId(ServiceClient, _data!.qrsQuoteId);

            if (leads.Entities?.Count > 0)
            {
                throw new Exception($"Lead found for QRS Quote ID: {_data.qrsQuoteId}. A new lead will not be created.");
            }

            await CreateLead(_data, TriggerTimeStamp);

            return Task.CompletedTask;
        }

        private async Task CreateLead(QrsPayload qrsPayload, DateTime TriggerTimeStamp)
        {
            var lead = new Entity(Lead.EntityLogicalName);

            // Set MMO Integration Modified on to Trigger Timestamp.
            lead[Lead.Fields.MMo_Integration_Modified_On] = TriggerTimeStamp;

            lead[Lead.Fields.MMo_Business_Area_Choice] = new OptionSetValue((int)MMo_Business_Area_Gc.GroupSales);
            lead[Lead.Fields.MMo_Data_Scrub_Complete] = true;
            lead[Lead.Fields.MMo_Initial_Data_Scrub_Complete] = new OptionSetValue((int)MSeVTmGt_NoOrYes.Yes);
            lead[Lead.Fields.MMo_Lead_Source_Choice] = new OptionSetValue((int)MMo_Lead_Source_Gc.FormfireEasyappsonline);
            lead[Lead.Fields.MMo_Lead_Stage_Status_Choice] = new OptionSetValue((int)MMo_Lead_Stage_Status_Gc.NewProspect);
            lead[Lead.Fields.MMo_Lead_Type_Choice] = new OptionSetValue((int)MMo_Lead_Type_Gc.NewBusiness);
            lead[Lead.Fields.StateCode] = new OptionSetValue((int)Lead_StateCode.Open);
            lead[Lead.Fields.StatusCode] = new OptionSetValue((int)Lead_StatusCode.New);
            lead[Lead.Fields.Address1_Country] = "USA";
            lead[Lead.Fields.Address2_Country] = "USA";
            lead[Lead.Fields.MMo_SameAddress_Gc] = new OptionSetValue((int)MMo_YesNo_Gc.Yes);
            lead[Lead.Fields.MMo_Same_Address_Choice] = new OptionSetValue((int)MSeVTmGt_NoOrYes.Yes);
            lead[Lead.Fields.ProcessId] = new Guid("1DEE521F-8934-EF11-840A-6045BDD65460");

            if (!string.IsNullOrWhiteSpace(qrsPayload.submissionDate))
            {
                lead[Lead.Fields.MMo_Application_Received_Date] = DateTime.Parse(qrsPayload.submissionDate, null, DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal);
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.qrsQuoteId))
            {
                lead[Lead.Fields.MMo_QRS_QuoteId_Text] = qrsPayload.qrsQuoteId;
                lead[Lead.Fields.MMo_Integration_Source_Id_Text] = $"QRS-{qrsPayload.qrsQuoteId}";
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.qrsQuoteStatus))
            {
                var status = CrmHelper.QrsQuoteStatus(qrsPayload.qrsQuoteStatus);
                lead[Lead.Fields.MMo_QRS_Status_Choice] = new OptionSetValue(Convert.ToInt32(status));
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.quoteEffectiveDate))
            {
                lead[Lead.Fields.MMo_Effective_Date] = DateTime.Parse(qrsPayload.quoteEffectiveDate, null, DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal);
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.eligibleCount))
            {
                lead[Lead.Fields.MMo_Total_Eligible_Employees] = Convert.ToInt32(qrsPayload.eligibleCount);
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.totalCount))
            {
                lead[Lead.Fields.NumberOfEmployees] = Convert.ToInt32(qrsPayload.totalCount);
                lead[Lead.Fields.MMo_Total_Number_Of_Employees] = Convert.ToInt32(qrsPayload.totalCount);

                var count = CrmHelper.EmployeeCount(Convert.ToInt32(qrsPayload.totalCount));
                lead[Lead.Fields.MMo_Segment_Choice] = new OptionSetValue(count);
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.agencyId))
            {
                var accountId = GetAccountId(qrsPayload.agencyId, (int)Account_CustomerTypeCode.BrokerAgency);
                if (accountId != Guid.Empty)
                {
                    lead[Lead.Fields.MMo__Broker_Agency_Id] = new EntityReference(Account.EntityLogicalName, accountId);
                }
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.agentId))
            {
                var contact = GetContactId(qrsPayload.agentId);
                if (contact != null)
                {
                    lead[Lead.Fields.MMo_Broker_Name_Id] = new EntityReference(Contact.EntityLogicalName, contact.Id);
                }
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.groupName))
            {
                lead[Lead.Fields.CompanyName] = qrsPayload.groupName;
                lead[Lead.Fields.Subject] = qrsPayload.groupName;
                lead[Lead.Fields.LastName] = qrsPayload.groupName;
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.streetAddress1))
            {
                lead[Lead.Fields.Address1_Line1] = qrsPayload.streetAddress1;
                lead[Lead.Fields.Address2_Line1] = qrsPayload.streetAddress1;
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.streetAddress2))
            {
                lead[Lead.Fields.Address1_Line2] = qrsPayload.streetAddress2;
                lead[Lead.Fields.Address2_Line2] = qrsPayload.streetAddress2;
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.city))
            {
                lead[Lead.Fields.Address1_City] = qrsPayload.city;
                lead[Lead.Fields.Address2_City] = qrsPayload.city;
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.state))
            {
                lead[Lead.Fields.Address1_StateOrProvince] = qrsPayload.state;
                lead[Lead.Fields.Address2_StateOrProvince] = qrsPayload.state;

                var stateId = await GetStateId(qrsPayload.state);
                if (stateId != Guid.Empty)
                {
                    lead[Lead.Fields.MMo_State_Id] = new EntityReference(HsL_State.EntityLogicalName, stateId);
                    lead[Lead.Fields.MMo_State_Id_Mailing] = new EntityReference(HsL_State.EntityLogicalName, stateId);
                }
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.zip))
            {
                lead[Lead.Fields.Address1_PostalCode] = qrsPayload.zip;
                lead[Lead.Fields.Address2_PostalCode] = qrsPayload.zip;
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.countyCode))
            {
                var county = await GetCountyId(qrsPayload.countyCode);
                if (county != null)
                {
                    lead[Lead.Fields.Address1_County] = county[MMo_County.Fields.MMo_Name];
                    lead[Lead.Fields.Address2_County] = county[MMo_County.Fields.MMo_Name];
                    lead[Lead.Fields.MMo_Address1_County_Id] = new EntityReference(MMo_County.EntityLogicalName, county.Id);
                    lead[Lead.Fields.MMo_Address2_County_Id] = new EntityReference(MMo_County.EntityLogicalName, county.Id);

                    var region = (OptionSetValue)county[MMo_County.Fields.MMo_Region];
                    if (region != null)
                    {
                        lead[Lead.Fields.MMo_Region_Choice] = region;
                    }
                }
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.ein))
            {
                var accountId = GetAccountIdByEin(qrsPayload.ein);

                if (accountId == Guid.Empty)
                {
                    accountId = await CreateAccount(qrsPayload, TriggerTimeStamp);
                }

                lead[Lead.Fields.CustomerId] = new EntityReference(Account.EntityLogicalName, accountId);
                lead[Lead.Fields.ParentAccountId] = new EntityReference(Account.EntityLogicalName, accountId);
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.sic))
            {
                lead[Lead.Fields.Sic] = qrsPayload.sic;
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.coverageIndicator))
            {
                var indicator = CrmHelper.CoverageIndicator(qrsPayload.coverageIndicator);
                lead[Lead.Fields.MMo_Coverage_Indicator_Choice] = new OptionSetValue(indicator);
            }

            var country = await GetCountryId("USA");
            if (country != null)
            {
                lead[Lead.Fields.MMo_Country_Id] = new EntityReference(MMo_Country.EntityLogicalName, country.Id);
                lead[Lead.Fields.MMo_Country_Mailing_Id] = new EntityReference(MMo_Country.EntityLogicalName, country.Id);
            }

            // Set Owner
            var owner = GetSmallGroupSalesConsultant(qrsPayload.agentId);
            if (owner != null && owner.Id != Guid.Empty)
            {
                lead[Lead.Fields.OwnerId] = owner;
            }

            if (string.IsNullOrWhiteSpace(qrsPayload.agentId) || string.IsNullOrWhiteSpace(qrsPayload.agencyId) || string.IsNullOrWhiteSpace(qrsPayload.ein))
            {
                lead[Lead.Fields.MMo_FormFire_Review_Choice] = new OptionSetValue((int)MSeVTmGt_NoOrYes.Yes);
            }

            // Create the lead and then qualify it with the returned id
            var leadId = Guid.Empty;
            try
            {
                leadId = await ServiceClient.CreateAsync(lead);
            }
            catch (Exception ex)
            {
                // Check if the exception is due to missing privileges
                if (ex.Message.Contains("missing prvReadLead privilege"))
                {
                    // Log the error
                    Logger.LogError($"User does not have the required privileges: {ex.Message}");

                    // Set the owner to the small group team instead.  Passing in null will return team.
                    lead[Lead.Fields.OwnerId] = GetSmallGroupSalesConsultant(null);

                    leadId = await ServiceClient.CreateAsync(lead);
                }
                else
                {
                    // Rethrow the exception if it's not related to privileges
                    throw;
                }
            }

            if (leadId == Guid.Empty)
            {
                throw new Exception($"Lead ID is empty.  Unable to qualify lead.");
            }

            // Set the traversedpath
            // We do not need to wait for the result of this function to continue the code.

            try
            {
                Xrm.AzureFunctions.Utility.CrmHelper.CompleteActiveBpf(ServiceClient, Logger, Lead.EntityLogicalName, leadId, "mmo_lead_sales_process", new Guid("cba532b6-27c6-497d-8227-27113ed3f89e"));
            }
            catch (Exception e)
            {
                Logger.LogWarning($"Error when trying completing the active BPF for lead ID {leadId}: {e.Message}");
            }

            // Qualify the lead
            var qualifyLeadRequest = new QualifyLeadRequest
            {
                CreateAccount = false,
                CreateContact = false,
                CreateOpportunity = true,
                LeadId = new EntityReference(Lead.EntityLogicalName, leadId),
                Status = new OptionSetValue((int)Lead_StatusCode.Commitment)
            };

            // Qualify the Lead
            QualifyLeadResponse qualifyLeadResponse = (QualifyLeadResponse)await ServiceClient.ExecuteAsync(qualifyLeadRequest);

            // Extract the new opportunity from the response
            var opportunityReference = qualifyLeadResponse.CreatedEntities?.FirstOrDefault(entity => entity.LogicalName == "opportunity");

            if (opportunityReference != null)
            {
                // Update New Opportunity's fields
                var opportunity = new Entity(Opportunity.EntityLogicalName, opportunityReference.Id)
                {
                    [Opportunity.Fields.MMo_Opportunity_Type_Choice] = new OptionSetValue((int)MMo_Opportunity_Type_Gc.NewBusiness),
                    [Opportunity.Fields.MMo_MHqCompleted_Yn] = new OptionSetValue((int)MMo_YesNo_Gc.Yes),

                };
                if (!string.IsNullOrWhiteSpace(qrsPayload.submissionDate))
                    opportunity[Opportunity.Fields.MMo_MHqCompletion_Date] = Convert.ToDateTime(qrsPayload.submissionDate);

                await ServiceClient.UpdateAsync(opportunity);
            }
        }

    }
}
