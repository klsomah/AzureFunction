﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MMO.Xrm.GroupSales.AzureFunctions.BusinessLogic
{
    public class RetryException : Exception
    {
        public RetryException(string message) : base(message)
        {
        }

        public RetryException(Exception innerException) : base(innerException.Message, innerException)
        {
        }

        public RetryException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }
}
