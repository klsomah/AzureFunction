﻿using System.Collections.ObjectModel;
using System.Globalization;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Extensions.Logging;
using Microsoft.PowerPlatform.Dataverse.Client;
using Microsoft.Rest;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using MMO.Xrm.AzureFunctions.Utility.Framework;
using MMO.Xrm.AzureFunctions.Utility.Framework.Interfaces;
using MMO.Xrm.GroupSales.AzureFunctions.BusinessLogic.Interfaces;
using MMO.Xrm.GroupSales.AzureFunctions.Payload;
using MMO.Xrm.Model;

namespace MMO.Xrm.GroupSales.AzureFunctions.BusinessLogic
{
    public class QrsBusinessLogic : IMessageProcessingBusinessLogic
    {
        private ILogger<QrsBusinessLogic> _logger { get; }
		private readonly IOrganizationServiceAsync2Pool _serviceClientPool;

        public QrsBusinessLogic(ILogger<QrsBusinessLogic> logger, IOrganizationServiceAsync2Pool serviceClientPool)
        {
            _logger = logger;
            _serviceClientPool = serviceClientPool;
        }

        public async Task<Task> SubmitQuote(QrsPayload payload, DateTime triggerTimestamp)
        {
            if (payload == null)
            {
                _logger.LogError("FormFire Submission payload is null, exiting SubmitQuote()");
                return Task.CompletedTask;
            }

            BusinessLogicBase businessLogic = new QrsSubmitBusinessLogic(_serviceClientPool, _logger, triggerTimestamp, payload);
            await businessLogic.ExecuteBusinessLogic();

            return Task.CompletedTask;
        }

        public async Task<Task> CompleteQuote(QrsPayload payload, DateTime triggerTimestamp)
        {
            if (payload == null)
            {
				_logger.LogError("Complete Quote payload is null, exiting CompleteQuote()");
				return Task.CompletedTask;
            }

            BusinessLogicBase businessLogic = new QrsCompleteBusinessLogic(_serviceClientPool, _logger, triggerTimestamp, payload);
			await businessLogic.ExecuteBusinessLogic();

            return Task.CompletedTask;
        }

		public async Task<Task> RenewQuote(QrsPayload payload, DateTime triggerTimestamp)
        {
            if (payload == null)
            {
				_logger.LogError("Renewal payload is null, exiting RenewQuote()");
				return Task.CompletedTask;
            }

            BusinessLogicBase businessLogic = new QrsRenewBusinessLogic(_serviceClientPool, _logger, triggerTimestamp, payload);
            await businessLogic.ExecuteBusinessLogic();

            return Task.CompletedTask;
		}

		public async Task<Task> ScheduledJobs()
        {
            BusinessLogicBase businessLogic = new ScheduledJobsBusinessLogic(_serviceClientPool, _logger, DateTime.Now);
            await businessLogic.ExecuteBusinessLogic();

            return Task.CompletedTask;
        }	
	}
}
