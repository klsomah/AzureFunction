﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.PowerPlatform.Dataverse.Client;
using Microsoft.Rest;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using MMO.Xrm.AzureFunctions.Utility.Framework.Interfaces;
using MMO.Xrm.GroupSales.AzureFunctions.Payload;
using MMO.Xrm.Model;

namespace MMO.Xrm.GroupSales.AzureFunctions.BusinessLogic
{
    internal abstract class BusinessLogicBase
    {
        private IOrganizationServiceAsync2Pool ServiceClientPool { get; set; }
        private protected IPoolingOrganizationServiceAsync2 ServiceClient { get; set; }
        private protected ILogger Logger { get; set; }
        //private protected ILockService LockService { get; set; }
        private protected DateTime TriggerTimeStamp { get; set; }

        internal BusinessLogicBase(IOrganizationServiceAsync2Pool serviceClientPool, ILogger logger, DateTime triggerTimeStamp)
        {
            ServiceClientPool = serviceClientPool;
            Logger = logger;
            //LockService = lockService;
            TriggerTimeStamp = triggerTimeStamp;
        }

        public async Task<Task> ExecuteBusinessLogic()
        {
            using (ServiceClient = await ServiceClientPool.Acquire(Logger))
            {
                return await AbstractBusinessLogic();
            }
        }

        internal abstract Task<Task> AbstractBusinessLogic();

        ///TODO: Logic that is shared between various business logic classes should go here.
        ///TODO: There are a lot of functions like "CreateSectionPlaceholder" that are recreated in a very similar fashion across multiple BL implementations

        #region Shared Get Logic

        public Guid GetAccountId(string agentId, int typeCode)
        {
            var accountId = Guid.Empty;
            var accounts = CrmHelper.GetAccountTaxId(ServiceClient, agentId, typeCode);

            if (accounts.Entities.Count <= 0) return accountId;
            var account = accounts.Entities[0];
            accountId = account.Id;

            return accountId;
        }

        public Guid GetAccountIdByEin(string ein)
        {
            var accountId = Guid.Empty;
            var accounts = CrmHelper.GetAccountByEin(ServiceClient, ein);

            var groupAccount = accounts.Entities
                .Where(x => x.GetAttributeValue<OptionSetValue>(Account.Fields.CustomerTypeCode).Value == (int)Account_CustomerTypeCode.EmployerGroup)
                .FirstOrDefault();

            if (groupAccount != null)
            {
                // Group Account found for EIN
                accountId = groupAccount.Id;
            }
            else
            {
                // Group Account not found, loop for a Prospective Group Account.
                var prospectiveGroupAccount = accounts.Entities
                    .Where(x => x.GetAttributeValue<OptionSetValue>(Account.Fields.CustomerTypeCode).Value == (int)Account_CustomerTypeCode.ProspectiveGroup)
                    .FirstOrDefault();

                if (prospectiveGroupAccount != null)
                {
                    // Prospective Group Account found for EIN
                    accountId = prospectiveGroupAccount.Id;
                }
            }

            return accountId;
        }

        public Entity? GetContactId(string agentId)
        {
            var contacts = CrmHelper.GetContactByTaxId(ServiceClient, agentId);

            if (contacts.Entities.Count <= 0) return null;
            var contact = contacts.Entities[0];

            return contact;
        }

        public async Task<Guid> GetStateId(string abbreviation)
        {
            var stateId = Guid.Empty;
            var states = await CrmHelper.GetStateByAbbreviation(ServiceClient, abbreviation);

            if (states.Entities.Count <= 0) return stateId;
            var state = states.Entities[0];
            stateId = state.Id;

            return stateId;
        }

        public async Task<Entity?> GetCountyId(string code)
        {
            var counties = await CrmHelper.GetCountyByCode(ServiceClient, code);

            if (counties.Entities.Count <= 0) return null;
            var county = counties.Entities[0];

            return county;
        }

        public async Task<Entity?> GetCountryId(string name)
        {
            var countries = await CrmHelper.GetCountryByName(ServiceClient, name);

            if (countries.Entities.Count <= 0) return null;
            var country = countries.Entities[0];

            return country;
        }

        public EntityReference GetSmallGroupSalesConsultant(string? agentId)
        {
            EntityReference? smallGroupSalesConsultantEntity = null;

            // Get Small Group Sales Consultant from Contact
            if (!string.IsNullOrWhiteSpace(agentId))
            {
                var contacts = CrmHelper.GetContactByTaxId(ServiceClient, agentId);

                if (contacts.Entities.Count > 1)
                    Logger.LogWarning($"Multiple Contacts found for Agent ID:{agentId}");

                if (contacts.Entities.Count > 0 && contacts.Entities[0].Contains(Contact.Fields.MMo_Small_Group_Sales_Consultant_Id))
                {
                    var userId = contacts.Entities[0].GetAttributeValue<EntityReference>(Contact.Fields.MMo_Small_Group_Sales_Consultant_Id).Id;
                    smallGroupSalesConsultantEntity = new EntityReference(SystemUser.EntityLogicalName, userId);
                }
            }

            // Team Fallback logic if Small Group Sales Consultant not found from Agent.
            if (smallGroupSalesConsultantEntity == null)
            {
                var smallGroupTeamId = Guid.Empty;
                var smallGroupTeamIdString = Environment.GetEnvironmentVariable("small-group-team-id");

                if (!string.IsNullOrWhiteSpace(smallGroupTeamIdString))
                {
                    try
                    {
                        smallGroupTeamId = new Guid(smallGroupTeamIdString);
                    }
                    catch
                    {
                        Logger.LogWarning("Unable to convert 'small-group-team-id' environment variable into a GUID.  Please check that the configuration has a valid unique identifier value.");
                    }
                }

                smallGroupSalesConsultantEntity = new EntityReference(Team.EntityLogicalName, smallGroupTeamId);
            }

            return smallGroupSalesConsultantEntity;
        }

        #endregion

        #region Shared Create/Update Logic

        public async Task<Guid> CreateAccount(QrsPayload qrsPayload, DateTime triggerTimestamp, Account_CustomerTypeCode customerTypeCode = Account_CustomerTypeCode.ProviderGroup)
        {
            var account = new Entity(Account.EntityLogicalName);

            // Set MMO Integration Modified on to Trigger Timestamp.
            account[Account.Fields.MMo_Integration_Modified_On] = triggerTimestamp;

            //bool consultantFound = false;
            if (!string.IsNullOrWhiteSpace(qrsPayload.groupName))
            {
                account[Account.Fields.Name] = qrsPayload.groupName;
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.streetAddress1))
            {
                account[Account.Fields.Address1_Line1] = qrsPayload.streetAddress1;
                account[Account.Fields.Address2_Line1] = qrsPayload.streetAddress1;
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.streetAddress2))
            {
                account[Account.Fields.Address1_Line2] = qrsPayload.streetAddress2;
                account[Account.Fields.Address2_Line2] = qrsPayload.streetAddress2;
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.city))
            {
                account[Account.Fields.Address1_City] = qrsPayload.city;
                account[Account.Fields.Address2_City] = qrsPayload.city;
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.state))
            {
                account[Account.Fields.Address1_StateOrProvince] = qrsPayload.state;
                account[Account.Fields.Address2_StateOrProvince] = qrsPayload.state;

                var stateId = await GetStateId(qrsPayload.state);
                if (stateId != Guid.Empty)
                {
                    account[Account.Fields.MMo_State_Physical_Id] = new EntityReference(HsL_State.EntityLogicalName, stateId);
                    account[Account.Fields.MMo_StateId_Mailing] = new EntityReference(HsL_State.EntityLogicalName, stateId);
                }
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.countyCode))
            {
                var county = await GetCountyId(qrsPayload.countyCode);
                if (county != null)
                {
                    account[Account.Fields.Address1_County] = county[MMo_County.Fields.MMo_Name];
                    account[Account.Fields.Address2_County] = county[MMo_County.Fields.MMo_Name];
                    account[Account.Fields.MMo_Address1_County_Id] = new EntityReference(MMo_County.EntityLogicalName, county.Id);
                    account[Account.Fields.MMo_Address2_County_Id] = new EntityReference(MMo_County.EntityLogicalName, county.Id);

                    var region = (OptionSetValue)county[MMo_County.Fields.MMo_Region];
                    if (region != null)
                    {
                        account[Account.Fields.MMo_Region_Choice] = region;
                    }
                }
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.zip))
            {
                account[Account.Fields.Address1_PostalCode] = qrsPayload.zip;
                account[Account.Fields.Address2_PostalCode] = qrsPayload.zip;
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.ein))
            {
                account[Account.Fields.HsL_FederalTaxId] = qrsPayload.ein;
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.sic))
            {
                account[Account.Fields.Sic] = qrsPayload.sic;
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.streetAddress1))
            {
                account[Account.Fields.Address1_Line1] = qrsPayload.streetAddress1;
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.eligibleCount))
            {
                account[Account.Fields.HsL_EligibleEmployees] = Convert.ToInt32(qrsPayload.eligibleCount);
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.totalCount))
            {
                account[Account.Fields.HsL_NoOfEmployees] = Convert.ToInt32(qrsPayload.totalCount);
                account[Account.Fields.NumberOfEmployees] = Convert.ToInt32(qrsPayload.totalCount);
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.agencyId))
            {
                var accountId = GetAccountId(qrsPayload.agencyId, (int)Account_CustomerTypeCode.BrokerAgency);
                if (accountId != Guid.Empty)
                {
                    account[Account.Fields.MMo_Broker_Agency_Id] = new EntityReference(Account.EntityLogicalName, accountId); //not in D365
                }
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.agentId))
            {
                var contact = GetContactId(qrsPayload.agentId);
                if (contact != null)
                {
                    account[Account.Fields.MMo_Broker_Name_Id] = new EntityReference(Contact.EntityLogicalName, contact.Id);
                }
            }

            // Set Owner
            var owner = GetSmallGroupSalesConsultant(qrsPayload.agentId);
            if (owner != null && owner.Id != Guid.Empty)
            {
                account[Account.Fields.OwnerId] = owner;
            }

            account[Account.Fields.Address1_Country] = "USA";
            account[Account.Fields.Address2_Country] = "USA";

            var country = await GetCountryId("USA");
            if (country != null)
            {
                account[Account.Fields.MMo_Country_Physical_Id] = new EntityReference(MMo_Country.EntityLogicalName, country.Id);
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.groupNumber))
            {
                account[Account.Fields.AccountNumber] = qrsPayload.groupNumber;
                account[Account.Fields.HsL_ClientNumber] = qrsPayload.groupNumber;
            }

            account[Account.Fields.MMo_Business_Area_Choice] = new OptionSetValue((int)MMo_Business_Area_Gc.GroupSales);
            account[Account.Fields.CustomerTypeCode] = new OptionSetValue((int)customerTypeCode);
            account[Account.Fields.MMo_SameAddress_Gc] = new OptionSetValue((int)MMo_YesNo_Gc.Yes);

            var accountGuid = await ServiceClient.CreateAsync(account);
            return accountGuid;
        }

        /// <summary>
		/// Upsert an Opportunity
		/// </summary>
		/// <param name="opportunityId"></param>
		/// <param name="qrsPayload"></param>
		/// <param name="qrsMessageType"></param>
		/// <returns></returns>
		public async Task UpsertOpportunity(Guid opportunityId, QrsPayload qrsPayload, QrsMessageType qrsMessageType, DateTime triggerTimestamp)
        {
            var opportunity = new Entity(Opportunity.EntityLogicalName, opportunityId);
            var isCreate = opportunityId == Guid.Empty;

            // Set MMO Integration Modified on to Trigger Timestamp.
            opportunity[Opportunity.Fields.MMo_Integration_Modified_On] = triggerTimestamp;

            // Set common fields
            await SetOpportunityFields_Shared(opportunity, qrsPayload);

            // Set fields unique to integration type
            switch (qrsMessageType)
            {
                case QrsMessageType.Submit:
                    break;
                case QrsMessageType.Complete:
                    await SetOpportunityFields_Complete(opportunity, qrsPayload, triggerTimestamp);
                    break;
                case QrsMessageType.Renew:
                    await SetOpportunityFields_Renew(opportunity, qrsPayload, isCreate, triggerTimestamp);
                    break;
                default:
                    break;
            }

            try
            {
                var upsertResponse = await ServiceClient.ExecuteAsync(new UpsertRequest { Target = opportunity });
            }
            catch (Exception ex)
            {
                // Check if the exception is due to missing privileges
                if (ex.Message.Contains("missing prvReadOpportunity privilege"))
                {
                    // Log the error
                    Logger.LogError($"User does not have the required privileges: {ex.Message}");

                    // Set the owner to the small group team instead.  Passing in null will return team.
                    opportunity[Opportunity.Fields.OwnerId] = GetSmallGroupSalesConsultant(null);

                    var upsertResponse = await ServiceClient.ExecuteAsync(new UpsertRequest { Target = opportunity });
                }
                else
                {
                    // Rethrow the exception if it's not related to privileges
                    throw;
                }
            }
        }



        #endregion

        #region Shared Helper Logic

        /// <summary>
		/// Set shared Opportunity fields
		/// </summary>
		/// <param name="opportunity"></param>
		/// <param name="qrsPayload"></param>
		/// <returns></returns>
		private async Task SetOpportunityFields_Shared(Entity opportunity, QrsPayload qrsPayload)
        {
            if (!string.IsNullOrWhiteSpace(qrsPayload.qrsQuoteStatus))
            {
                var status = CrmHelper.QrsQuoteStatus(qrsPayload.qrsQuoteStatus);
                opportunity[Opportunity.Fields.MMo_QRS_Status_Choice] = new OptionSetValue(Convert.ToInt32(status));
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.quoteEffectiveDate))
            {
                opportunity[Opportunity.Fields.MMo_Effective_Date] = DateTime.Parse(qrsPayload.quoteEffectiveDate, null, DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal);
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.eligibleCount))
            {
                opportunity[Opportunity.Fields.MMo_Total_Eligible_Employees] = Convert.ToInt32(qrsPayload.eligibleCount);
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.totalCount))
            {
                opportunity[Opportunity.Fields.HsL_TotalEmployees] = Convert.ToInt32(qrsPayload.totalCount);
                opportunity[Opportunity.Fields.MMo_Total_Number_Of_Employees] = Convert.ToInt32(qrsPayload.totalCount);
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.agencyId))
            {
                var accountId = GetAccountId(qrsPayload.agencyId, (int)Account_CustomerTypeCode.BrokerAgency);
                if (accountId != Guid.Empty)
                {
                    opportunity[Opportunity.Fields.MMo_Broker_Agency_Id] = new EntityReference(Account.EntityLogicalName, accountId); //not in D365
                }
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.agentId))
            {
                var contact = GetContactId(qrsPayload.agentId);
                if (contact != null)
                {
                    opportunity[Opportunity.Fields.MMo_Broker_Name_Id] = new EntityReference(Contact.EntityLogicalName, contact.Id);
                }
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.groupName))
            {
                opportunity[Opportunity.Fields.Name] = qrsPayload.groupName;
                opportunity[Opportunity.Fields.MMo_Company_Name] = qrsPayload.groupName;
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.coverageIndicator))
            {
                var indicator = CrmHelper.CoverageIndicator(qrsPayload.coverageIndicator);
                opportunity[Opportunity.Fields.MMo_Coverage_Indicator_Choice] = new OptionSetValue(indicator);
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.emc))
            {
                opportunity[Opportunity.Fields.MMo_EMc] = Convert.ToDecimal(qrsPayload.emc);
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.totalCount))
            {
                var count = CrmHelper.EmployeeCount(Convert.ToInt32(qrsPayload.totalCount));
                opportunity[Opportunity.Fields.MMo_Market_Segment_Choice] = new OptionSetValue(count);
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.tier))
            {
                var tier = CrmHelper.MedicalTier(Convert.ToInt32(qrsPayload.tier));
                if (tier > 0)
                {
                    opportunity[Opportunity.Fields.MMo_Medical_Tier_Choice] = new OptionSetValue(tier);
                }
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.countyCode))
            {
                var county = await GetCountyId(qrsPayload.countyCode);
                if (county != null)
                {
                    var region = (OptionSetValue)county[MMo_County.Fields.MMo_Region];
                    if (region != null)
                    {
                        opportunity[Opportunity.Fields.MMo_Region_Choice] = region;
                    }
                }
            }
        }

        /// <summary>
        /// Set Opportunity fields when processing Complete
        /// </summary>
        /// <param name="opportunity"></param>
        /// <param name="qrsPayload"></param>
        /// <returns></returns>
        private async Task SetOpportunityFields_Complete(Entity opportunity, QrsPayload qrsPayload, DateTime triggerTimestamp)
        {
            if (!string.IsNullOrWhiteSpace(qrsPayload.ein))
            {
                var accountId = GetAccountIdByEin(qrsPayload.ein);

                if (accountId == Guid.Empty)
                {
                    accountId = await CreateAccount(qrsPayload, triggerTimestamp);
                }

                opportunity[Opportunity.Fields.CustomerId] = new EntityReference(Account.EntityLogicalName, accountId);
                opportunity[Opportunity.Fields.ParentAccountId] = new EntityReference(Account.EntityLogicalName, accountId);
            }
        }

        /// <summary>
        /// Set Opportunity fields when processing Renewals
        /// </summary>
        /// <param name="opportunity"></param>
        /// <param name="qrsPayload"></param>
        /// <param name="isCreate"></param>
        /// <returns></returns>
        private async Task SetOpportunityFields_Renew(Entity opportunity, QrsPayload qrsPayload, bool isCreate, DateTime triggerTimestamp)
        {
            // Fields to set only when creating an opportunity
            if (isCreate)
            {
                if (!string.IsNullOrWhiteSpace(qrsPayload.qrsQuoteId))
                {
                    // If Opportunity ID is an empty Guid, we will create a new opportunity and need to set the QRS Quote ID
                    opportunity[Opportunity.Fields.MMo_QRS_QuoteId_Text] = qrsPayload.qrsQuoteId;
                    opportunity[Opportunity.Fields.MMo_Integration_Source_Id_Text] = $"QRS-{qrsPayload.qrsQuoteId}";
                }

                // Defaults
                opportunity[Opportunity.Fields.MMo_Business_Area_Choice] = new OptionSetValue((int)MMo_Business_Area_Gc.GroupSales);
                opportunity[Opportunity.Fields.StateCode] = new OptionSetValue((int)Opportunity_StateCode.Open);
                opportunity[Opportunity.Fields.StatusCode] = new OptionSetValue((int)Opportunity_StatusCode.InProgress);
                opportunity[Opportunity.Fields.MMo_Opportunity_Type_Choice] = new OptionSetValue((int)MMo_Opportunity_Type_Gc.Renewal);

                // Set Owner
                var owner = GetSmallGroupSalesConsultant(qrsPayload.agentId);
                if (owner != null && owner.Id != Guid.Empty)
                {
                    opportunity[Opportunity.Fields.OwnerId] = owner;
                }

                if (!string.IsNullOrWhiteSpace(qrsPayload.approvedDate))
                {
                    opportunity[Opportunity.Fields.OverriddenCreatedOn] = DateTime.Parse(qrsPayload.approvedDate, null, DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal);
                }
            }

            // Fields to set on both create and update
            if (!string.IsNullOrWhiteSpace(qrsPayload.coverageIndicator))
            {
                opportunity[Opportunity.Fields.MMo_PlanType] = qrsPayload.coverageIndicator;
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.renewalDate))
            {
                opportunity[Opportunity.Fields.MMo_Renewal_Date] = DateTime.Parse(qrsPayload.renewalDate, null, DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal);
            }

            if (!string.IsNullOrWhiteSpace(qrsPayload.groupNumber))
            {
                var accountId = Guid.Empty;

                // Find Account by Group Number
                var accounts = CrmHelper.GetAccountByGroupNumber(ServiceClient, qrsPayload.groupNumber);

                if (accounts.Entities.Count > 0)
                {
                    // Use the account id found by Group Number
                    accountId = accounts.Entities[0].Id;
                }
                else
                {
                    // If an Account cannot be found by Group Number, try to find an account by EIN.
                    if (!string.IsNullOrWhiteSpace(qrsPayload.ein))
                    {
                        //accountId = GetAccountId(qrsPayload.ein, (int)MMo_AccountType_Code.Group);
                        accountId = GetAccountIdByEin(qrsPayload.ein);
                    }
                }

                // If an account was not found in the above logic, create the Employer Group account
                if (accountId == Guid.Empty)
                {
                    accountId = await CreateAccount(qrsPayload, triggerTimestamp, Account_CustomerTypeCode.EmployerGroup);
                }

                if (accountId != Guid.Empty)
                {
                    opportunity[Opportunity.Fields.CustomerId] = new EntityReference(Account.EntityLogicalName, accountId);
                    opportunity[Opportunity.Fields.ParentAccountId] = new EntityReference(Account.EntityLogicalName, accountId);
                }
            }
        }


        #endregion

    }
}
