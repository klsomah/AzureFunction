﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using MMO.Xrm.AzureFunctions.Utility.Framework.Interfaces;
using MMO.Xrm.GroupSales.AzureFunctions.Payload;
using MMO.Xrm.Model;

namespace MMO.Xrm.GroupSales.AzureFunctions.BusinessLogic
{
    internal class QrsRenewBusinessLogic : BusinessLogicBase
    {
        private QrsPayload _data { get; }

        internal QrsRenewBusinessLogic(IOrganizationServiceAsync2Pool serviceClientPool, ILogger logger, DateTime TriggerTimeStamp, QrsPayload data)
            : base(serviceClientPool, logger, TriggerTimeStamp)
        {
            _data = data;
        }

        internal async override Task<Task> AbstractBusinessLogic()
        {
            // Find an existing Opportunity
            var opportunities = CrmHelper.GetOpportunitiesByMmoQrsQuoteId(ServiceClient, _data!.qrsQuoteId);

            if (opportunities.Entities.Count == 0)
            {
                // Create new Opportunity
                await UpsertOpportunity(Guid.Empty, _data, QrsMessageType.Renew, TriggerTimeStamp);
            }
            else
            {
                if (opportunities.Entities.Count > 1)
                {
                    Logger.LogWarning($"Multiple Opportunities found for QRS Quote ID:{_data!.qrsQuoteId}.  All Opportunities found will be updated.");
                }

                foreach (var opportunity in opportunities.Entities)
                {
                    // Update Opportunity
                    if (opportunity != null)
                    {
                        // Prevent out of sequence processing
                        opportunity.TryGetAttributeValue<DateTime>(Opportunity.Fields.MMo_Integration_Modified_On, out DateTime integrationModifiedOn);
                        if (integrationModifiedOn > TriggerTimeStamp)
                        {
                            throw new Exception($"Stale Data due to TriggerTimeStamp.");
                        }

                        await UpsertOpportunity(opportunity.Id, _data, QrsMessageType.Renew, TriggerTimeStamp);
                    }
                }
            }

            return Task.CompletedTask;
        }
    }
}
