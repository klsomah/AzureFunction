using Azure.Core;
using Azure.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.PowerPlatform.Dataverse.Client;
using MMO.Xrm.GroupSales.AzureFunctions.BusinessLogic;
using MMO.Xrm.GroupSales.AzureFunctions.BusinessLogic.Interfaces;
using MMO.Xrm.GroupSales.AzureFunctions.Framework;
using MMO.Xrm.GroupSales.AzureFunctions.Framework.Interfaces;
using MMO.Xrm.AzureFunctions.Utility.Framework;
using MMO.Xrm.AzureFunctions.Utility.Framework.Interfaces;

var host = new HostBuilder()
    .ConfigureAppConfiguration(config =>
    {
        config.AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
            .AddEnvironmentVariables();
    })
    .ConfigureFunctionsWorkerDefaults()
    .ConfigureServices((context, services) =>
    {
        // ASB
        var maxRetryCount = context.Configuration.GetValue<int>("ServiceBusMaxRetryCount");
        services.AddSingleton<IServiceBusConfiguration>(new ServiceBusConfiguration(maxRetryCount));

        // Dataverse - Connection Pooling
        services.AddSingleton<IOrganizationServiceAsync2Pool, OrganizationServiceAsync2Pool>(sp =>
        {
            var crmUri = Environment.GetEnvironmentVariable("crm-url");
            var use5SPs = Environment.GetEnvironmentVariable("crm-use-five-service-principals");
            var managedIdentity = new DefaultAzureCredential();

            if (string.IsNullOrEmpty(crmUri))
            {
                throw new InvalidOperationException("Crm-Url is not set in environment variable");
            }

            IOrganizationServiceAsync2Supplier connectionSupplier = new ManagedIdentityIOrganizationServiceAsync2Supplier(crmUri, managedIdentity);

            // Check if we need to do round-robbin using Service Principals (migration only)
            if (use5SPs == "true")
            {
                // go with a round robbin approach with 5 SPs
                // pull the client ids/secrets from the Envrionment Variables
                const int servicePrincipalCount = 5;

                string[] clientIds = new string[servicePrincipalCount];
                string[] clientSecrets = new string[servicePrincipalCount];

                for (int i = 0; i < servicePrincipalCount; i++)
                {
                    clientIds[i] = Environment.GetEnvironmentVariable($"client-id-{i + 1}");
                    clientSecrets[i] = Environment.GetEnvironmentVariable($"client-secret-{i + 1}");
                }

                connectionSupplier = new ServicePrincipalIOrganizationServiceAsync2Supplier(crmUri, clientIds, clientSecrets);
            }

            // Otherwise, use default ManagedIdentity connection (should be fine for integration)
            return new OrganizationServiceAsync2Pool(
                connectionSupplier,
                // how long to keep connections before dropping them
                TimeSpan.FromHours(1),
                // how long to wait on a connection from the pool when you reach the max number of connections
                TimeSpan.FromSeconds(5),
                // the maximum number of connections
                100,
                // how long to wait before trying to get another connection if creating a new one fails
                TimeSpan.FromMilliseconds(100));

        });

        // Distributed Lock
        services.AddSingleton<IBlobContainerClientFactory>(sp =>
		{
			var locksContainer = Environment.GetEnvironmentVariable("distributed-locks-container");
			var locksStorageAccount = Environment.GetEnvironmentVariable("distributed-locks-storage-account");
			if (string.IsNullOrEmpty(locksContainer) || string.IsNullOrEmpty(locksStorageAccount))
			{
				throw new InvalidOperationException("Distributed lock environment variables are not set");
			}
			string containerEndpoint = $"{locksStorageAccount}/{locksContainer}";
			return new BlobContainerClientFactory(containerEndpoint);
		});

		services.AddSingleton(sp =>
		{
			var factory = sp.GetRequiredService<IBlobContainerClientFactory>();
			return factory.CreateClient();
		});

		services.AddTransient<ILockService, LockService>();

		// Others
		services.AddScoped<IMessageProcessor, MessageProcessor>();
        services.AddScoped<IRetryHandler, ExponentialRetryHandler>();
        services.AddScoped<IMessageProcessingBusinessLogic, QrsBusinessLogic>();
    })
.Build();

await host.RunAsync();

