﻿using Azure.Messaging.ServiceBus;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using MMO.Xrm.GroupSales.AzureFunctions.Framework.Interfaces;

namespace MMO.Xrm.GroupSales.AzureFunctions.Framework
{
    public class ExponentialRetryHandler: IRetryHandler
    {
        private readonly ILogger<ExponentialRetryHandler> _logger;
        private readonly int _maxRetryCount;

        public ExponentialRetryHandler(ILogger<ExponentialRetryHandler> logger, IServiceBusConfiguration serviceBusConfiguration)
        {
            _logger = logger;
            _maxRetryCount = serviceBusConfiguration.MaxRetryCount;
        }

        public async Task RetryAsync(ServiceBusReceivedMessage message, ServiceBusMessageActions messageActions)
        {
            if (message.DeliveryCount > _maxRetryCount)
            {
                _logger.LogError("Maximum retry count exceeded. Dead Lettering the message.");

                await messageActions.DeadLetterMessageAsync(message);
                return;
            }

            var delay = CalculateRetryDelay(message.DeliveryCount);
            _logger.LogWarning("Retrying the message. Delivery count: {deliveryCount}. Delay: {delay}", message.DeliveryCount, delay);

            // Delay before abandoning the message to retry
            await Task.Delay(delay);

            await messageActions.AbandonMessageAsync(message);
        }

        private static TimeSpan CalculateRetryDelay(int deliveryCount)
        {
            return TimeSpan.FromSeconds(Math.Pow(deliveryCount, 2));
        }
    }
}
