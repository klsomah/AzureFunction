﻿namespace MMO.Xrm.GroupSales.AzureFunctions.Framework.Interfaces
{
    public interface IServiceBusConfiguration
    {
        int MaxRetryCount { get; }
    }
}
