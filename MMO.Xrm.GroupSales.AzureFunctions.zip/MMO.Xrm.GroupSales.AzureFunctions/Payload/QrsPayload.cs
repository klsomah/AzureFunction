﻿namespace MMO.Xrm.GroupSales.AzureFunctions.Payload
{
    public class QrsPayload
    {
        public string submissionDate { get; set; }
        public string qrsQuoteId { get; set; }
        public string qrsQuoteStatus { get; set; }
        public string quoteEffectiveDate { get; set; }
        public string eligibleCount { get; set; }
        public string totalCount { get; set; }
        public string medicalMedicareCount { get; set; }
        public string agencyId { get; set; }
        public string agentId { get; set; }
        public string groupName { get; set; }
        public string streetAddress1 { get; set; }
        public string streetAddress2 { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string zip { get; set; }
        public string countyCode { get; set; }
        public string ein { get; set; }
        public string sic { get; set; }
        public string coverageIndicator { get; set; }
        public string emc { get; set; }
        public string tier { get; set; }
        public string approvedDate { get; set; }
        public string renewalDate { get; set; }
        public string groupNumber { get; set; }
    }
}