﻿using Azure.Storage.Blobs;
using Medallion.Threading.Azure;
using Microsoft.Extensions.Logging;
using MMO.Xrm.AzureFunctions.Utility.Framework.Interfaces;

namespace MMO.Xrm.AzureFunctions.Utility.Framework
{
	public class LockService : ILockService
	{
		private readonly BlobContainerClient _containerClient;

		public LockService(BlobContainerClient containerClient)
		{
			_containerClient = containerClient;
		}

		public AzureBlobLeaseDistributedLock GetLock(string lockName)
		{
			return new AzureBlobLeaseDistributedLock(_containerClient, lockName);
		}

		public async Task ExecuteWithDistributedLock(ILogger log, string lockName, Func<Task> function)
		{
			if (string.IsNullOrEmpty(lockName))
			{
				throw new Exception("Lockname cannot be null or empty.");
			}

			var @lock = GetLock(lockName);

			log.LogDebug($"Attempting to acquire lock {lockName}");

			try
			{
				await using (var handle = await @lock.TryAcquireAsync(TimeSpan.FromMinutes(2)))
				{
					if (handle != null)
					{
						log.LogInformation($"Lock {lockName} obtained");
						await function();
					}
					else
					{
						throw new Exception($"Failed to obtain a lock on {lockName}");
					}
				}
			}
			finally
			{
				// Closing the using will ensure that the lock is automatically released
				log.LogInformation($"Lock {lockName} released");
			}
		}
	}
}
