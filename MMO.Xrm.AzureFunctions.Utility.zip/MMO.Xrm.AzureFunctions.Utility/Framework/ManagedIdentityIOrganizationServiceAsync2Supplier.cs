﻿using Azure.Core;
using Azure.Identity;
using Microsoft.PowerPlatform.Dataverse.Client;
using MMO.Xrm.AzureFunctions.Utility.Framework.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;

namespace MMO.Xrm.AzureFunctions.Utility.Framework
{
    public class ManagedIdentityIOrganizationServiceAsync2Supplier : IOrganizationServiceAsync2Supplier
    {
        private readonly string _crmUrl;
        private readonly DefaultAzureCredential _defaultAzureCredential;

        public ManagedIdentityIOrganizationServiceAsync2Supplier(
            string crmUrl, 
            DefaultAzureCredential defaultAzureCredential)
        {
            _crmUrl = crmUrl;
            _defaultAzureCredential = defaultAzureCredential;
        }

        public Task<IOrganizationServiceAsync2> CreateConnection()
        {
            return Task.FromResult<IOrganizationServiceAsync2>(new ServiceClient(new Uri(_crmUrl), tokenProviderFunction: async u =>
                (await _defaultAzureCredential.GetTokenAsync(
                    new TokenRequestContext(new[] { $"{_crmUrl}/.default" }))).Token
                ));
        }
    }
}
