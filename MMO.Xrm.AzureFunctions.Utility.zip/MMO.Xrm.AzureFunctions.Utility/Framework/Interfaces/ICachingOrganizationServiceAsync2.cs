﻿using Microsoft.PowerPlatform.Dataverse.Client;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace MMO.Xrm.AzureFunctions.Utility.Framework.Interfaces
{
    public interface ICachingOrganizationServiceAsync2 : IOrganizationServiceAsync2
    {
        Task<EntityCollection> CachedRetrieveMultipleAsync(QueryBase query);
        Task<EntityCollection> CachedRetrieveMultipleAsync(QueryBase query, TimeSpan absoluteExpiration, TimeSpan slidingExpiration);

        Task<Entity> CachedRetrieveAsync(string entityName, Guid id, ColumnSet columnSet);
        Task<Entity> CachedRetrieveAsync(string entityName, Guid id, ColumnSet columnSet, TimeSpan absoluteExpiration, TimeSpan slidingExpiration);

        Task<(TResult, TCachedData)> CachedOperationAsync<TResult, TCachedData>(string key, Func<Task<(TResult, TCachedData, bool)>> operation);
        Task<(TResult, TCachedData)> CachedOperationAsync<TResult, TCachedData>(string key, Func<Task<(TResult, TCachedData, bool)>> operation, TimeSpan absoluteExpiration, TimeSpan slidingExpiration);
    }
}
