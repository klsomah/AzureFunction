﻿using Microsoft.PowerPlatform.Dataverse.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MMO.Xrm.AzureFunctions.Utility.Framework.Interfaces
{
    public interface IOrganizationServiceAsync2Supplier
    {
        Task<IOrganizationServiceAsync2> CreateConnection();
    }
}
