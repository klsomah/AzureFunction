﻿using Medallion.Threading.Azure;
using Microsoft.Extensions.Logging;

namespace MMO.Xrm.AzureFunctions.Utility.Framework.Interfaces
{
	public interface ILockService
	{
		AzureBlobLeaseDistributedLock GetLock(string lockName);
		Task ExecuteWithDistributedLock(ILogger log, string lockName, Func<Task> function);
	}
}
