﻿using Azure.Storage.Blobs;

namespace MMO.Xrm.AzureFunctions.Utility.Framework.Interfaces
{
	public interface IBlobContainerClientFactory
	{
		BlobContainerClient CreateClient();
	}
}
