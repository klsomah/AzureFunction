﻿using Azure.Identity;
using Azure.Storage.Blobs;
using MMO.Xrm.AzureFunctions.Utility.Framework.Interfaces;

namespace MMO.Xrm.AzureFunctions.Utility.Framework
{
	public class BlobContainerClientFactory : IBlobContainerClientFactory
	{
		private readonly string _containerEndpoint;

		public BlobContainerClientFactory(string containerEndpoint)
		{
			_containerEndpoint = containerEndpoint;
		}

		public BlobContainerClient CreateClient()
		{
			return new BlobContainerClient(new Uri(_containerEndpoint), new DefaultAzureCredential());
		}
	}
}
