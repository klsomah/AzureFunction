﻿using Azure.Core;
using Azure.Identity;
using Microsoft.PowerPlatform.Dataverse.Client;
using MMO.Xrm.AzureFunctions.Utility.Framework.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;

namespace MMO.Xrm.AzureFunctions.Utility.Framework
{
    public class ServicePrincipalIOrganizationServiceAsync2Supplier : IOrganizationServiceAsync2Supplier
    {
        private readonly string _crmUrl;
        private readonly string[] _clientIds;
        private readonly string[] _clientSecrets;

        private readonly object _lock = new object();
        private int _current;

        public ServicePrincipalIOrganizationServiceAsync2Supplier(
            string crmUrl,
            string clientId,
            string clientSecret)
        {
            _crmUrl = crmUrl;
            _clientIds = new string[] { clientId };
            _clientSecrets = new string[] { clientSecret };

            _current = 0;
        }

        public ServicePrincipalIOrganizationServiceAsync2Supplier(
            string crmUrl, 
            string[] clientIds,
            string[] clientSecrets)
        {
            if (clientIds == null || clientSecrets == null)
                throw new NullReferenceException("The clientIds and clientSecrets arrays cannot be null");

            if (clientIds.Length != clientSecrets.Length)
                throw new ArgumentException("You must supply the same number of client ids and secrets");

            if (clientIds.Length <= 0)
                throw new ArgumentException("You must supply at least one client id and one secret");

            _crmUrl = crmUrl;
            _clientIds = clientIds;
            _clientSecrets = clientSecrets;

            _current = 0;
        }

        public Task<IOrganizationServiceAsync2> CreateConnection()
        {
            // we don't need locking if we're only given one service principal to use
            if (_clientIds.Length == 1) {
                return Task.FromResult(CreateNewConnection(0));
            }

            // if we're given more than one, then we need to lock to ensure we always
            // cycle through and create an equal number of connections per service principal
            IOrganizationServiceAsync2 connection = null;
            lock (_lock) 
            {
                connection = CreateNewConnection(_current);
                
                _current++;

                if (_current >= _clientIds.Length)
                    _current = 0;

            }

            return Task.FromResult(connection);
        }

        private IOrganizationServiceAsync2 CreateNewConnection(int index)
        {
            return new ServiceClient($"AuthType=ClientSecret;url={_crmUrl};ClientId={_clientIds[index]};ClientSecret={_clientSecrets[index]}");
        }
    }
}
