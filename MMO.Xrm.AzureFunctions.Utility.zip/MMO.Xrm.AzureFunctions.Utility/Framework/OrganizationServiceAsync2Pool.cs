﻿using Microsoft.PowerPlatform.Dataverse.Client;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using MMO.Xrm.AzureFunctions.Utility.Framework.Interfaces;
using System.Collections.Concurrent;
using System.Transactions;

namespace MMO.Xrm.AzureFunctions.Utility.Framework
{
    public class OrganizationServiceAsync2Pool : IOrganizationServiceAsync2Pool
    {
        private readonly SemaphoreSlim _maxConnectionLock;
        private readonly IOrganizationServiceAsync2Supplier _connectionSupplier;
        private readonly ConcurrentQueue<DisposableCachingOrganizationServiceAsync2> _connectionPool;

        private readonly TimeSpan _maxConnectionLifetime;
        private readonly TimeSpan _maxWaitForConnection;
        private readonly TimeSpan? _connectionRetryWaitTime;

        public OrganizationServiceAsync2Pool(
            IOrganizationServiceAsync2Supplier connectionSupplier,
            TimeSpan maxConnectionLifetime,
            TimeSpan maxWaitForConnection,
            int maxNumberOfConnections,
            TimeSpan? connectionRetryWaitTime)
        {
            _maxConnectionLock = new SemaphoreSlim(0, maxNumberOfConnections);
            _connectionSupplier = connectionSupplier;
            _connectionPool = new ConcurrentQueue<DisposableCachingOrganizationServiceAsync2>();
            _maxConnectionLifetime = maxConnectionLifetime;
            _maxWaitForConnection = maxWaitForConnection;
            _connectionRetryWaitTime = connectionRetryWaitTime;
        }

        public async Task<IPoolingOrganizationServiceAsync2> Acquire()
        {
            // make sure we only release out X number of connections
            if (await _maxConnectionLock.WaitAsync(_maxWaitForConnection))
            {
                // attempt to get one from the Pool
                var connection = GetOrExpireConnection();
                if (connection != null)
                    return connection;

                // attempt to create a new one
                connection = await CreateNewConnection();
                if (connection != null)
                    return connection;

                // welp... that's all folks
                throw new Exception("Failed to get an existing connection and failed to create a new connection.");
            }

            throw new TimeoutException($"Failed to get a connection - {_maxConnectionLock.CurrentCount} connections are currently being held.");
        }

        private DisposableCachingOrganizationServiceAsync2? GetOrExpireConnection()
        {
            // continue to pop connections off the queue until we get one that's valid
            while (_connectionPool.TryDequeue(out var connection))
            {
                if (connection.IsValid())
                {
                    connection.Prepare();
                    return connection;
                }
                else
                {
                    connection.Close();
                }
            }

            // no more left in the queue to use
            return null;
        }

        private async Task<DisposableCachingOrganizationServiceAsync2?> CreateNewConnection()
        {
            IOrganizationServiceAsync2 service = await _connectionSupplier.CreateConnection();
            var connection = new DisposableCachingOrganizationServiceAsync2(service, this);

            if (connection.IsValid())
            {
                return connection;
            }

            if (_connectionRetryWaitTime == null)
            {
                connection.ThrowNewConnectionException();
                return null;
            }

            // wait a bit
            await Task.Delay(_connectionRetryWaitTime.Value);

            // try again...
            service = await _connectionSupplier.CreateConnection();
            connection = new DisposableCachingOrganizationServiceAsync2(service, this);

            if (connection.IsValid())
            {
                return connection;
            }

            connection.ThrowNewConnectionException();
            return null;
        }
    
        private void Return(DisposableCachingOrganizationServiceAsync2 service)
        {
            _connectionPool.Enqueue(service);
            _maxConnectionLock.Release();
        }

        private class DisposableCachingOrganizationServiceAsync2 : CachingOrganizationServiceAsync2, IPoolingOrganizationServiceAsync2, IOrganizationServiceAsync2, IDisposable
        {
            /// <summary>
            /// Just a reference to the parent pool to support disposal (returning this back to the pool)
            /// </summary>
            private readonly OrganizationServiceAsync2Pool _pool;

            /// <summary>
            /// A lock object to make sure disposal and closing happen by a single thread
            /// </summary>
            private readonly object _lock = new object();

            /// <summary>
            /// Tracking of when the connection was created so we can have a maximum connection lifetime
            /// </summary>
            private readonly DateTime _created;

            /// <summary>
            /// Whether the connection has been disposed (put back in the pool)
            /// </summary>
            private bool _isDisposed;

            /// <summary>
            /// Whether the connection has been closed (no longer should be used)
            /// </summary>
            private bool _isClosed;

            /// <summary>
            /// This is just for ease of closing/check for readiness
            /// 
            /// the cast here is annoying but we shouldn't be
            /// seeing any other concrete type anyway...
            /// all uses below are safe anyway
            /// </summary>
            private ServiceClient? _serviceClient
            {
                get
                {
                    return _client as ServiceClient;
                }
            }

            public DisposableCachingOrganizationServiceAsync2(
                IOrganizationServiceAsync2 service,
                OrganizationServiceAsync2Pool pool) : base(service)
            {
                _pool = pool;
                _created = DateTime.UtcNow;
                _isDisposed = false;
                _isClosed = false;
            }

            public bool IsValid()
            {
                if (_created.Add(_pool._maxConnectionLifetime) < DateTime.UtcNow)
                    return false;

                if (_isClosed)
                    return false;

                if (_serviceClient != null && !_serviceClient.IsReady)
                    return false;

                return true;
            }

            public Exception ThrowNewConnectionException()
            {
                if (_serviceClient != null)
                {
                    Exception ex = _serviceClient.LastException;
                    string message = _serviceClient.LastError;

                    if (ex != null)
                        throw new Exception(message, ex);

                    throw new Exception(message);
                }

                throw new Exception($"Connection is invalid: Unknown error created = {_created}, isClosed = {_isClosed}, isDisposed = {_isDisposed}");
            }

            public void Prepare()
            {
                if (_serviceClient != null)
                    _serviceClient.CallerId = Guid.Empty;

                _isDisposed = false;
            }

            public void Dispose()
            {
                bool wasDisposed = false;
                lock (_lock)
                {
                    if (!_isDisposed)
                    {
                        _isDisposed = wasDisposed = true;
                    }
                }

                if (wasDisposed)
                {
                    _pool.Return(this);
                }
            }

            public void Close()
            {
                bool wasClosed = false;
                lock (_lock)
                {
                    if (!_isClosed)
                    {
                        _isClosed = wasClosed = true;
                    }
                }

                if (wasClosed)
                {
                    if (_serviceClient != null)
                        _serviceClient.Dispose();
                }
            }

            private void ThrowIfClosedOrDisposed()
            {
                if (_isDisposed)
                    throw new ObjectDisposedException($"The {nameof(IPoolingOrganizationServiceAsync2)} is being used after being returned back to the pool");

                if (_isClosed)
                    throw new ObjectDisposedException($"The {nameof(IPoolingOrganizationServiceAsync2)} is being used after being closed");
            }

            #region Delegated Methods

            public override Task<Entity> CachedRetrieveAsync(string entityName, Guid id, ColumnSet columnSet)
            {
                ThrowIfClosedOrDisposed();
                return base.CachedRetrieveAsync(entityName, id, columnSet);
            }

            public override Task<Entity> CachedRetrieveAsync(string entityName, Guid id, ColumnSet columnSet, TimeSpan absoluteExpiration, TimeSpan slidingExpiration)
            {
                ThrowIfClosedOrDisposed();
                return base.CachedRetrieveAsync(entityName, id, columnSet, absoluteExpiration, slidingExpiration);
            }

            public override Task<EntityCollection> CachedRetrieveMultipleAsync(QueryBase query)
            {
                ThrowIfClosedOrDisposed();
                return base.CachedRetrieveMultipleAsync(query);
            }

            public override Task<EntityCollection> CachedRetrieveMultipleAsync(QueryBase query, TimeSpan absoluteExpiration, TimeSpan slidingExpiration)
            {
                ThrowIfClosedOrDisposed();
                return base.CachedRetrieveMultipleAsync(query, absoluteExpiration, slidingExpiration);
            }

            public override Task<(TResult, TCachedData)> CachedOperationAsync<TResult, TCachedData>(string key, Func<Task<(TResult, TCachedData, bool)>> operation)
            {
                ThrowIfClosedOrDisposed();
                return base.CachedOperationAsync(key, operation);
            }

            public override Task<(TResult, TCachedData)> CachedOperationAsync<TResult, TCachedData>(string key, Func<Task<(TResult, TCachedData, bool)>> operation, TimeSpan absoluteExpiration, TimeSpan slidingExpiration)
            {
                ThrowIfClosedOrDisposed();
                return base.CachedOperationAsync(key, operation, absoluteExpiration, slidingExpiration);
            }

            public override void Associate(string entityName, Guid entityId, Relationship relationship, EntityReferenceCollection relatedEntities)
            {
                ThrowIfClosedOrDisposed();
                base.Associate(entityName, entityId, relationship, relatedEntities);
            }

            public override async Task AssociateAsync(string entityName, Guid entityId, Relationship relationship, EntityReferenceCollection relatedEntities, CancellationToken cancellationToken)
            {
                ThrowIfClosedOrDisposed();
                await base.AssociateAsync(entityName, entityId, relationship, relatedEntities, cancellationToken);
            }

            public override async Task AssociateAsync(string entityName, Guid entityId, Relationship relationship, EntityReferenceCollection relatedEntities)
            {
                ThrowIfClosedOrDisposed();
                await base.AssociateAsync(entityName, entityId, relationship, relatedEntities);
            }

            public override Guid Create(Entity entity)
            {
                ThrowIfClosedOrDisposed();
                return base.Create(entity);
            }

            public override async Task<Entity> CreateAndReturnAsync(Entity entity, CancellationToken cancellationToken)
            {
                ThrowIfClosedOrDisposed();
                return await base.CreateAndReturnAsync(entity, cancellationToken);
            }

            public override async Task<Guid> CreateAsync(Entity entity, CancellationToken cancellationToken)
            {
                ThrowIfClosedOrDisposed();
                return await base.CreateAsync(entity, cancellationToken);
            }

            public override async Task<Guid> CreateAsync(Entity entity)
            {
                ThrowIfClosedOrDisposed();
                return await base.CreateAsync(entity);
            }

            public override void Delete(string entityName, Guid id)
            {
                ThrowIfClosedOrDisposed();
                base.Delete(entityName, id);
            }

            public override async Task DeleteAsync(string entityName, Guid id, CancellationToken cancellationToken)
            {
                ThrowIfClosedOrDisposed();
                await base.DeleteAsync(entityName, id, cancellationToken);
            }

            public override async Task DeleteAsync(string entityName, Guid id)
            {
                ThrowIfClosedOrDisposed();
                await base.DeleteAsync(entityName, id);
            }

            public override void Disassociate(string entityName, Guid entityId, Relationship relationship, EntityReferenceCollection relatedEntities)
            {
                ThrowIfClosedOrDisposed();
                base.Disassociate(entityName, entityId, relationship, relatedEntities);
            }

            public override async Task DisassociateAsync(string entityName, Guid entityId, Relationship relationship, EntityReferenceCollection relatedEntities, CancellationToken cancellationToken)
            {
                ThrowIfClosedOrDisposed();
                await base.DisassociateAsync(entityName, entityId, relationship, relatedEntities, cancellationToken);
            }

            public override async Task DisassociateAsync(string entityName, Guid entityId, Relationship relationship, EntityReferenceCollection relatedEntities)
            {
                ThrowIfClosedOrDisposed();
                await base.DisassociateAsync(entityName, entityId, relationship, relatedEntities);
            }

            public override OrganizationResponse Execute(OrganizationRequest request)
            {
                ThrowIfClosedOrDisposed();
                return base.Execute(request);
            }

            public override async Task<OrganizationResponse> ExecuteAsync(OrganizationRequest request, CancellationToken cancellationToken)
            {
                ThrowIfClosedOrDisposed();
                return await base.ExecuteAsync(request, cancellationToken);
            }

            public override async Task<OrganizationResponse> ExecuteAsync(OrganizationRequest request)
            {
                ThrowIfClosedOrDisposed();
                return await base.ExecuteAsync(request);
            }

            public override Entity Retrieve(string entityName, Guid id, ColumnSet columnSet)
            {
                ThrowIfClosedOrDisposed();
                return base.Retrieve(entityName, id, columnSet);
            }

            public override async Task<Entity> RetrieveAsync(string entityName, Guid id, ColumnSet columnSet, CancellationToken cancellationToken)
            {
                ThrowIfClosedOrDisposed();
                return await base.RetrieveAsync(entityName, id, columnSet);
            }

            public override async Task<Entity> RetrieveAsync(string entityName, Guid id, ColumnSet columnSet)
            {
                ThrowIfClosedOrDisposed();
                return await base.RetrieveAsync(entityName, id, columnSet);
            }

            public override EntityCollection RetrieveMultiple(QueryBase query)
            {
                ThrowIfClosedOrDisposed();
                return base.RetrieveMultiple(query);
            }

            public override async Task<EntityCollection> RetrieveMultipleAsync(QueryBase query, CancellationToken cancellationToken)
            {
                ThrowIfClosedOrDisposed();
                return await base.RetrieveMultipleAsync(query, cancellationToken);
            }

            public override async Task<EntityCollection> RetrieveMultipleAsync(QueryBase query)
            {
                ThrowIfClosedOrDisposed();
                return await base.RetrieveMultipleAsync(query);
            }

            public override void Update(Entity entity)
            {
                ThrowIfClosedOrDisposed();
                base.Update(entity);
            }

            public override async Task UpdateAsync(Entity entity, CancellationToken cancellationToken)
            {
                ThrowIfClosedOrDisposed();
                await base.UpdateAsync(entity, cancellationToken);
            }

            public override async Task UpdateAsync(Entity entity)
            {
                ThrowIfClosedOrDisposed();
                await base.UpdateAsync(entity);
            }

            #endregion
        }
    }
}
