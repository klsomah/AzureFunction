﻿using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using Microsoft.PowerPlatform.Dataverse.Client;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using MMO.Xrm.AzureFunctions.Utility.Framework.Interfaces;
using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace MMO.Xrm.AzureFunctions.Utility.Framework
{
    public class CachingOrganizationServiceAsync2 : ICachingOrganizationServiceAsync2, IOrganizationServiceAsync2
    {
        protected readonly IOrganizationServiceAsync2 _client;
        private readonly MemoryCache _cache;

        public CachingOrganizationServiceAsync2(IOrganizationServiceAsync2 client)
        {
            _client = client;
            _cache = new MemoryCache(new MemoryCacheOptions
            {

            });
        }

        #region Caching Methods

        public virtual async Task<EntityCollection> CachedRetrieveMultipleAsync(QueryBase query)
        {
            // Default to 8 hours absolute & 1 hour sliding expiration
            return await CachedRetrieveMultipleAsync(query, TimeSpan.FromHours(8), TimeSpan.FromHours(1));
        }

        public virtual async Task<EntityCollection> CachedRetrieveMultipleAsync(QueryBase query, TimeSpan absoluteExpiration, TimeSpan slidingExpiration)
        {
            string key = "";

            if (query != null && query is FetchExpression)
            {
                key = ((FetchExpression)query).Query;
            }
            else
            {
                throw new ArgumentException("Input query is not a FetchExpression", "query");
            }

            return await _cache.GetOrCreateAsync(key, (entry) =>
            {
                // Remove it from the cache after 8 hours no matter what
                entry.SetAbsoluteExpiration(absoluteExpiration);

                // If it doesn't get accessed after an hour, then remove it from the cache
                entry.SetSlidingExpiration(slidingExpiration);

                // Perform the query and cache it
                return _client.RetrieveMultipleAsync(query);
            });
        }

        public virtual async Task<Entity> CachedRetrieveAsync(string entityName, Guid id, ColumnSet columnSet)
        {
            // Default to 8 hours absolute & 1 hour sliding expiration
            return await CachedRetrieveAsync(entityName, id, columnSet, TimeSpan.FromHours(8), TimeSpan.FromHours(1));
        }

        public virtual async Task<Entity> CachedRetrieveAsync(string entityName, Guid id, ColumnSet columnSet, TimeSpan absoluteExpiration, TimeSpan slidingExpiration)
        {
            if (!String.IsNullOrEmpty(entityName) || id == Guid.Empty || columnSet == null )
            {
                throw new ArgumentException("One of the arguments is missing a value");
            }

            string cols = columnSet.AllColumns ? "all" : string.Join(",", columnSet.Columns.Order());
            string key = $"{entityName}-{id}-{cols}";

            return await _cache.GetOrCreateAsync(key, (entry) => {
                // Remove it from the cache after 8 hours no matter what
                entry.SetAbsoluteExpiration(absoluteExpiration);

                // If it doesn't get accessed after an hour, then remove it from the cache
                entry.SetSlidingExpiration(slidingExpiration);

                // Perform the query and cache it
                return _client.RetrieveAsync(entityName, id, columnSet);
            });
        }

        public virtual async Task<(TResult, TCachedData)> CachedOperationAsync<TResult, TCachedData>(string key, Func<Task<(TResult, TCachedData, bool)>> operation)
        {
            return await CachedOperationAsync(key, operation, TimeSpan.FromHours(8), TimeSpan.FromHours(1));
        }

        public virtual async Task<(TResult, TCachedData)> CachedOperationAsync<TResult, TCachedData>(string key, Func<Task<(TResult, TCachedData, bool)>> operation, TimeSpan absoluteExpiration, TimeSpan slidingExpiration)
        {
            return await GetOrCreateCacheItemAsync(key, operation, absoluteExpiration, slidingExpiration);
        }

        #region Caching Helpers

        private async Task<(TResult, TCachedData)> GetOrCreateCacheItemAsync<TResult, TCachedData>(object key, Func<Task<(TResult, TCachedData, bool)>> factory, TimeSpan absoluteExpiration, TimeSpan slidingExpiration)
        {
            if (!_cache.TryGetValue(key, out TCachedData item))
            {
                (TResult? result, TCachedData data, bool useCache) = await factory();

                if (!useCache)
                    return (result, data);

                using ICacheEntry entry = _cache.CreateEntry(key);
                entry.Value = data;
                entry.SetAbsoluteExpiration(absoluteExpiration);
                entry.SetSlidingExpiration(slidingExpiration);
            }

            return (default(TResult), item);
        }

        #endregion

        #endregion

        #region Delegated Methods

        public virtual void Associate(string entityName, Guid entityId, Relationship relationship, EntityReferenceCollection relatedEntities)
        {
            _client.Associate(entityName, entityId, relationship, relatedEntities);
        }

        public virtual async Task AssociateAsync(string entityName, Guid entityId, Relationship relationship, EntityReferenceCollection relatedEntities, CancellationToken cancellationToken)
        {
            await _client.AssociateAsync(entityName, entityId, relationship, relatedEntities, cancellationToken);
        }

        public virtual async Task AssociateAsync(string entityName, Guid entityId, Relationship relationship, EntityReferenceCollection relatedEntities)
        {
            await _client.AssociateAsync(entityName, entityId, relationship, relatedEntities);
        }

        public virtual Guid Create(Entity entity)
        {
            return _client.Create(entity);
        }

        public virtual async Task<Entity> CreateAndReturnAsync(Entity entity, CancellationToken cancellationToken)
        {
            return await _client.CreateAndReturnAsync(entity, cancellationToken);
        }

        public virtual async Task<Guid> CreateAsync(Entity entity, CancellationToken cancellationToken)
        {
            return await _client.CreateAsync(entity, cancellationToken);
        }

        public virtual async Task<Guid> CreateAsync(Entity entity)
        {
            return await _client.CreateAsync(entity);
        }

        public virtual void Delete(string entityName, Guid id)
        {
            _client.Delete(entityName, id);
        }

        public virtual async Task DeleteAsync(string entityName, Guid id, CancellationToken cancellationToken)
        {
            await _client.DeleteAsync(entityName, id, cancellationToken);
        }

        public virtual async Task DeleteAsync(string entityName, Guid id)
        {
            await _client.DeleteAsync(entityName, id);
        }

        public virtual void Disassociate(string entityName, Guid entityId, Relationship relationship, EntityReferenceCollection relatedEntities)
        {
            _client.Disassociate(entityName, entityId, relationship, relatedEntities);
        }

        public virtual async Task DisassociateAsync(string entityName, Guid entityId, Relationship relationship, EntityReferenceCollection relatedEntities, CancellationToken cancellationToken)
        {
            await _client.DisassociateAsync(entityName, entityId, relationship, relatedEntities, cancellationToken);
        }

        public virtual async Task DisassociateAsync(string entityName, Guid entityId, Relationship relationship, EntityReferenceCollection relatedEntities)
        {
			await _client.DisassociateAsync(entityName, entityId, relationship, relatedEntities);
        }

        public virtual OrganizationResponse Execute(OrganizationRequest request)
        {
            return _client.Execute(request);
        }

        public virtual async Task<OrganizationResponse> ExecuteAsync(OrganizationRequest request, CancellationToken cancellationToken)
        {
            return await _client.ExecuteAsync(request, cancellationToken);
        }

        public virtual async Task<OrganizationResponse> ExecuteAsync(OrganizationRequest request)
        {
            return await _client.ExecuteAsync(request);
        }

        public virtual Entity Retrieve(string entityName, Guid id, ColumnSet columnSet)
        {
            return _client.Retrieve(entityName, id, columnSet);
        }

        public virtual async Task<Entity> RetrieveAsync(string entityName, Guid id, ColumnSet columnSet, CancellationToken cancellationToken)
        {
            return await _client.RetrieveAsync(entityName, id, columnSet);
        }

        public virtual async Task<Entity> RetrieveAsync(string entityName, Guid id, ColumnSet columnSet)
        {
            return await _client.RetrieveAsync(entityName, id, columnSet);
        }

        public virtual EntityCollection RetrieveMultiple(QueryBase query)
        {
            return _client.RetrieveMultiple(query);
        }

        public virtual async Task<EntityCollection> RetrieveMultipleAsync(QueryBase query, CancellationToken cancellationToken)
        {
            return await _client.RetrieveMultipleAsync(query, cancellationToken);
        }

        public virtual async Task<EntityCollection> RetrieveMultipleAsync(QueryBase query)
        {
            return await _client.RetrieveMultipleAsync(query);
        }

        public virtual void Update(Entity entity)
        {
            _client.Update(entity);
        }

        public virtual async Task UpdateAsync(Entity entity, CancellationToken cancellationToken)
        {
            await _client.UpdateAsync(entity, cancellationToken);
        }

        public virtual async Task UpdateAsync(Entity entity)
        {
            await _client.UpdateAsync(entity);
        }

        #endregion
    }
}
