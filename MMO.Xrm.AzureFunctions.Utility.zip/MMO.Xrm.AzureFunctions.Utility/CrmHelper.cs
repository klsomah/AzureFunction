﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Extensions.Logging;
using Microsoft.PowerPlatform.Dataverse.Client;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using MMO.Xrm.Model;

namespace MMO.Xrm.AzureFunctions.Utility
{
    public static class CrmHelper
    {
        /// <summary>
        /// Used to update or create a record in CRM.  Method will look to see if the enity Guid is Empty and decide to create or update.
        /// Use this instead of an Upsert Request for compatibility with plugins.
        /// </summary>
        /// <param name="serviceClient"></param>
        /// <param name="entity"></param>
        /// <returns>Guid of the Entity Updated or Created</returns>
        public async static Task<Guid> Upsert(IOrganizationServiceAsync2 serviceClient, Entity entity)
        {
            var returnValue = entity.Id;

            if (entity.Id != Guid.Empty)
            {
                await serviceClient.UpdateAsync(entity);
            }
            else
            {
                returnValue = await serviceClient.CreateAsync(entity);
            }

            return returnValue;
        }

        /// <summary>
        /// Out-of-sequence Message Checking and Create Target Entities
        /// Overloaded method takes an entity collection and then passes a List to the main method.
        /// </summary>
        /// <param name="existingEntities"></param>
        /// <param name="integrationModifiedOnFieldName"></param>
        /// <param name="triggerTimeStamp"></param>
        /// <param name="logger"></param>
        /// <returns>List of entities to be used for handling business logic updates or creates</returns>
        public static List<Entity> HandleOutOfSequenceProcessingAndCreateTargets(EntityCollection existingEntities, string integrationModifiedOnFieldName, DateTime triggerTimeStamp, ILogger logger)
        {
            return HandleOutOfSequenceCheckingAndCreateTargets(existingEntities.Entities.ToList(), existingEntities.EntityName, integrationModifiedOnFieldName, triggerTimeStamp, logger);
        }

        /// <summary>
        /// Out-of-sequence Message Checking and Create Target Entities
        /// Use this method to create update or create target entities and also check for out of sequence processing to prevent stale data updates.  
        /// Entity list past in should include the records Intergration Modified On attribute as well as the name of the attribute.
        /// Do this check first before do any further business logic to help with performance.
        /// </summary>
        /// <param name="existingEntities"></param>
        /// <param name="entityLogicalName"></param>
        /// <param name="integrationModifiedOnFieldName"></param>
        /// <param name="triggerTimeStamp"></param>
        /// <param name="logger"></param>
        /// <returns>List of entities to be used for handling business logic updates or creates</returns>
        /// <exception cref="Exception"></exception>
        public static List<Entity> HandleOutOfSequenceCheckingAndCreateTargets(List<Entity>? existingEntities, string entityLogicalName, string integrationModifiedOnFieldName, DateTime triggerTimeStamp, ILogger logger)
        {
            List<Entity> targets = new List<Entity>();

            if ((bool)existingEntities?.Any())
            {
                // Prevent out of sequence processing before updating the Entity.
                foreach (Entity entity in existingEntities)
                {
                    entity.TryGetAttributeValue<DateTime>(integrationModifiedOnFieldName, out DateTime integrationModifiedOn);

                    // Check to see if the message timestamp is older than the entities integration modified on this way we do not update with stale data.
                    if (integrationModifiedOn > triggerTimeStamp)
                    {
                        if (existingEntities.Count < 1) continue;
                        // Since there is only one entity found, throw an exception to dead letter the service bus message and stop processing.
                        logger.LogWarning($"Stale Data due to TriggerTimestamp.");
                        throw new Exception($"Stale Data due to TriggerTimestamp.");

                    }

                    // Add the entity or entities to a list for handling CRM updates
                    targets.Add(new Entity(entity.LogicalName, entity.Id));
                }
			}
			else
			{
				// No existing records found, a new record will be created
				targets.Add(new Entity(entityLogicalName));
			}

            return targets;
        }

        /// <summary>
        /// Remove Unchanged attributes from an entity by comparing against the latest version in CRM
        /// </summary>
        /// <param name="serviceClient"></param>
        /// <param name="targetEntity"></param>
        /// <returns>An Entity with only changed attributes</returns>
        public static Entity RemoveUnchangedAttributes(IOrganizationServiceAsync2 serviceClient, Entity targetEntity)
        {
            // Don't run logic for new records, only for updates to existing records.
            if (targetEntity.Id == Guid.Empty)
            {
                return targetEntity;
            }

            // Create a ColumnSet with the attributes present in targetEntity
            var columnSet = new ColumnSet(targetEntity.Attributes.Keys.ToArray());

            // Retrieve the current state of the opportunity entity from CRM
            var sourceEntity = serviceClient.Retrieve(targetEntity.LogicalName, targetEntity.Id, columnSet);

            // Remove attributes from targetEntity that are the same as in sourceEntity
            foreach (var attribute in targetEntity.Attributes.ToList())
            {
                if (sourceEntity.Contains(attribute.Key))
                {
                    var sourceValue = sourceEntity[attribute.Key];
                    var targetValue = attribute.Value;

                    // Compare values and remove if they are the same
                    if (ValuesAreEqual(sourceValue, targetValue))
                    {
                        targetEntity.Attributes.Remove(attribute.Key);
                    }
                }
            }

            return targetEntity;
        }

        /// <summary>
        /// Helper method to compare values
        /// </summary>
        /// <param name="value1"></param>
        /// <param name="value2"></param>
        /// <returns>bool indicating if the values are equal</returns>
        public static bool ValuesAreEqual(object value1, object value2)
        {
            if (value1 == null && value2 == null)
            {
                return true;
            }

            if (value1 == null || value2 == null)
            {
                return false;
            }

            return value1.Equals(value2);
        }

        /// <summary>
        /// Strips all non digit characters from a string.  Used for removing formating from phone numbers
        /// </summary>
        /// <param name="input"></param>
        /// <returns>A string consisiting of only numeric characters, all non numerica characters are removed</returns>
        /// <exception cref="ArgumentNullException"></exception>
        public static string StripNonDigitCharacters(string input)
        {
            if (input == null)
                throw new ArgumentNullException(nameof(input));

            // Use Regex to replace all non-digit characters with an empty string
            return Regex.Replace(input, @"\D", string.Empty);
        }


        /// <summary>
        /// Will move a business process flow to its final stage and set the status as "Finished".
        /// Please note: you MUST satisfy the required fields of each BPF stage first or this code will fail.
        /// </summary>
        /// <param name="serviceClient">CRM Service Client which will perform API operations</param>
        /// <param name="regardingEntityLogicalName">The logical name of the entity that contains the BPF</param>
        /// <param name="regardingEntityId">The ID of the entity that contains the BPF</param>
        /// <param name="targetBpfLogicalName">The uniquename of the BPF</param>
        /// <param name="finalStageId">The ID of the final BPF stage. If none is provided, this will be queried for</param>
        /// <returns>A completed task</returns>
        public async static Task<Task> CompleteActiveBpf(IOrganizationServiceAsync2 serviceClient, string regardingEntityLogicalName, Guid regardingEntityId, string targetBpfLogicalName, Guid? finalStageId = null)
        {
            // Retrieve the curently active BPF instance for the regarding entity record
            RetrieveProcessInstancesRequest req = new RetrieveProcessInstancesRequest
            {
                EntityLogicalName = regardingEntityLogicalName,
                EntityId = regardingEntityId
            };

            var response = (RetrieveProcessInstancesResponse)await serviceClient.ExecuteAsync(req);

            if (response.Processes.Entities.Count > 0)
            {
                // First record is the active process instance
                Entity activeProcessInstance = response.Processes.Entities.First();
                Guid activeProcessId = activeProcessInstance.Id;

                // If the final stage ID is not provided, then query for it
                if (finalStageId == null)
                {
                    // Retrieve the process stages in the active path of the current process instance
                    RetrieveActivePathRequest pathReq = new RetrieveActivePathRequest
                    {
                        ProcessInstanceId = activeProcessId
                    };
                    RetrieveActivePathResponse pathResp = (RetrieveActivePathResponse)await serviceClient.ExecuteAsync(pathReq);

                    // Retrieve the stage ID of the FINAL stage that you want to set as active
                    int totalStages = pathResp.ProcessStages.Entities.Count;
                    finalStageId = (Guid)pathResp.ProcessStages.Entities[totalStages - 1].Attributes["processstageid"];
                }                

                // Set the active stage to the final stage and mark the BPF as "Finished"
                Entity existingProcessInstance = new Entity(targetBpfLogicalName, activeProcessId);
                existingProcessInstance["activestageid"] = new EntityReference("processstage", (Guid)finalStageId);
                existingProcessInstance["statecode"] = new OptionSetValue(1);  //1 == Inactive
                existingProcessInstance["statuscode"] = new OptionSetValue(2); //2 == Finished
                await serviceClient.UpdateAsync(existingProcessInstance);
            }
            else
            {
                throw new Exception($"No BPF found for the {targetBpfLogicalName} record with ID {regardingEntityId}");
            }

            return Task.CompletedTask;
        }
    }
}
