﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.PowerPlatform.Dataverse.Client;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using MMO.Xrm.AzureFunctions.Utility.Framework.Interfaces;
using MMO.Xrm.Model;

namespace MMO.Xrm.AzureFunctions.Utility
{
	public static class AddressHelper
	{
		public static async Task<Entity?> GetCountryId(ICachingOrganizationServiceAsync2 cachingServiceClient, string countryName)
		{
			var countries = await GetCountryByName(cachingServiceClient, countryName);

			if (countries.Entities.Count <= 0) return null;
			var country = countries.Entities[0];

			return country;
		}

		public static async Task<EntityReference?> GetCountryEntityReference(ICachingOrganizationServiceAsync2 cachingServicesClient, string countryName)
		{
			var country = await GetCountryId(cachingServicesClient, countryName);
			if (country != null)
			{
				return new EntityReference(MMo_Country.EntityLogicalName, country.Id);
			}

			return null;
		}

		public static async Task<Guid> GetStateId(ICachingOrganizationServiceAsync2 cachingServiceClient, string abbreviation)
		{
			var stateId = Guid.Empty;
			var states = await GetStateIdFromAbbreviation(cachingServiceClient, abbreviation);
			if (states.Entities.Any())
			{
				stateId = states.Entities[0].GetAttributeValue<Guid>(HsL_State.Fields.Id);
			}
			return stateId;
		}

		public static async Task<EntityReference?> GetStateEntityReference(ICachingOrganizationServiceAsync2 cachingServiceClient, string abbreviation)
		{
			var stateId = await GetStateId(cachingServiceClient, abbreviation);
			if (stateId != Guid.Empty)
			{
				 return new EntityReference(HsL_State.EntityLogicalName, stateId);
			}
		    
			return null;
		}

		private static async Task<EntityCollection> GetStateIdFromAbbreviation(ICachingOrganizationServiceAsync2 cachingServiceClient, string? stateAbbr)
		{
			string fetchXml = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='{HsL_State.EntityLogicalName}'>
                                    <attribute name='{HsL_State.Fields.HsL_StateId}'/>
                                    <filter type='and'>
                                      <condition attribute='{HsL_State.Fields.HsL_Abbreviation}' operator='eq' value='{stateAbbr}'/>
                                    </filter>
                                    <order attribute='{HsL_State.Fields.ModifiedOn}' descending='true' />
                                  </entity>
                                </fetch> ";

			FetchExpression contactQuery = new FetchExpression(fetchXml);

			EntityCollection contactCollection = await cachingServiceClient.CachedRetrieveMultipleAsync(contactQuery);
			return contactCollection;
		}

		public static async Task<EntityCollection> GetCountryByName(ICachingOrganizationServiceAsync2 cachingServiceClient, string name)
		{
			string fetchXml = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                   <entity name='{MMo_Country.EntityLogicalName}'>
                                     <attribute name='{MMo_Country.Fields.MMo_CountryId}'/>
                                     <attribute name='{MMo_Country.Fields.MMo_Name}'/>
                                     <filter type='and'>
                                       <condition attribute='{MMo_Country.Fields.MMo_Name}' operator='eq' value='{name}'/>
                                     </filter>
                                     <order attribute='modifiedon' descending='true' />
                                   </entity>
                                 </fetch>";

			FetchExpression countryQuery = new FetchExpression(fetchXml);

			EntityCollection countryCollection = await cachingServiceClient.CachedRetrieveMultipleAsync(countryQuery);
			return countryCollection;
		}

		public static async Task<Guid> GetCountyId(ICachingOrganizationServiceAsync2 cachingServiceClient, string countyCode)
		{
			var countyId = Guid.Empty;
			var counties = await GetCountyByCode(cachingServiceClient, countyCode);

			if (counties.Entities.Any())
			{
				countyId = counties.Entities[0].GetAttributeValue<Guid>(MMo_County.Fields.Id);
			}
			return countyId;
		}

		public static async Task<EntityReference?> GetCountyEntityReference(ICachingOrganizationServiceAsync2 cachingServiceClient, string countyCode)
		{
			var countyId = await GetCountyId(cachingServiceClient, countyCode);
			if (countyId != Guid.Empty)
			{
				return new EntityReference(MMo_County.EntityLogicalName, countyId);
			}

			return null;
		}

		public static async Task<EntityCollection> GetCountyByCode(ICachingOrganizationServiceAsync2 cachingServiceClient, string countyCode)
		{

			string fetchXml = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                   <entity name='{MMo_County.EntityLogicalName}'>
                                     <attribute name='{MMo_County.Fields.MMo_CountyId}'/>
                                     <attribute name='{MMo_County.Fields.MMo_Name}'/>
                                     <attribute name='{MMo_County.Fields.MMo_Region}'/>
                                     <filter type='and'>
                                       <condition attribute='{MMo_County.Fields.MMo_County_Code}' operator='eq' value='{countyCode}'/>
                                     </filter>
                                     <order attribute='modifiedon' descending='true' />
                                   </entity>
                                 </fetch>";

			FetchExpression countyQuery = new FetchExpression(fetchXml);

			EntityCollection countyCollection = await cachingServiceClient.CachedRetrieveMultipleAsync(countyQuery);
			return countyCollection;
		}
	}
}
