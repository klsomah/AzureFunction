﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.JavaScript;
using System.Text;
using System.Threading.Tasks;

namespace MMO.Xrm.AzureFunctions.Utility
{
	public static class DateHelper
	{
		public static DateTime GetFirstRenewalDateAfterToday(string monthString)
		{
			int month = int.Parse(monthString);
			return GetFirstRenewalDateAfterToday(month);
		}

		public static DateTime GetFirstRenewalDateAfterToday(int month)
		{
			DateTime today = DateTime.Today;
			DateTime renewalDate = new DateTime(today.Year, month, 1);

			// If the renewal date is before or equal to today, move to the next year
			if (renewalDate <= today)
			{
				renewalDate = renewalDate.AddYears(1);
			}

			return renewalDate;
		}

        public static DateTime GetDateFromString(string dateString)
        {
            const string format = "MMddyyyy";
            return DateTime.ParseExact(dateString, format, null);
        }
	}
}
